# Validation Report - Requirements vs Database Schema

## Executive Summary
Đã rà soát toàn bộ **Use Cases**, **Business Requirements**, và **Database Schema (ERD)**. Tổng thể hệ thống đã được thiết kế **khá đầy đủ** và có tính nhất quán cao. Tuy nhiên, có một số điểm cần bổ sung để hoàn thiện.

---

## ✅ Các chức năng đã được hỗ trợ đầy đủ

### 1. Quản Lý Phim (UC02)
- ✅ **Bảng `Movies`** đã có đầy đủ trường: Title, Description, Director, Duration, ReleaseDate, Genre, PosterPath, Status
- ✅ Hỗ trợ trạng thái phim: COMING_SOON, SHOWING, STOPPED (ứng với use case "Cập nhật trạng thái")
- ✅ Lưu trữ thông tin đầy đủ theo yêu cầu nghiệp vụ

### 2. Quản Lý Lịch Chiếu (UC03)
- ✅ **Bảng `Showtimes`** có: MovieID, HallID, StartTime, EndTime, BasePrice
- ✅ Có thể kiểm tra trùng lặp dựa trên (HallID, StartTime, EndTime)
- ✅ Lưu BasePrice để hỗ trợ tính giá vé

### 3. Quản Lý Phòng & Ghế (UC04)
- ✅ **Bảng `CinemaHalls`**: Name, TotalRows, TotalCols
- ✅ **Bảng `Seats`**: HallID, RowLabel, SeatNumber, SeatType (VIP/STANDARD), IsActive
- ✅ Constraint UNIQUE(HallID, RowLabel, SeatNumber) - Ngăn trùng lặp ghế

### 4. Bán Vé (UC08)
- ✅ **Bảng `Bookings`**: Lưu thông tin giao dịch, có StaffID (nhân viên bán), CustomerID (khách hàng)
- ✅ **Bảng `Tickets`**: Chi tiết từng vé (ShowtimeID, SeatID, Price)
- ✅ Constraint UNIQUE(ShowtimeID, SeatID) - Đảm bảo 1 ghế trong 1 suất chiếu chỉ bán 1 lần
- ✅ Hỗ trợ tích điểm qua bảng `Customers` (LoyaltyPoints)

### 5. Quản Lý Ca (UC12)
- ✅ **Bảng `Shifts`**: StaffID, StartTime, EndTime, StartCash, EndCash
- ✅ Hỗ trợ đầy đủ nghiệp vụ "Mở ca" và "Chốt ca"

### 6. Đăng Ký Thành Viên (UC11)
- ✅ **Bảng `Customers`**: FullName, Phone, Email, LoyaltyPoints
- ✅ Có thể tích điểm cho khách hàng thành viên

---

## ⚠️ Các điểm cần bổ sung hoặc làm rõ

### 1. Nghiệp vụ: "Giữ ghế tạm thời" (Business Requirement 2.1)
**Hiện trạng:**
- Trong phần nghiệp vụ có đề cập: *"Khi nhân viên chọn ghế, hệ thống tạm giữ ghế đó trong X phút để tránh nhân viên khác bán trùng."*

**Vấn đề:**
- Database hiện tại **CHƯA CÓ** mechanism để lưu trạng thái "Đang giữ tạm thời".
- Cần thêm một trong hai giải pháp:
  - **Giải pháp 1 (Đơn giản)**: Thêm bảng `SeatReservations` (Temporary locks)
  - **Giải pháp 2**: Thêm cột `LockedBy`, `LockedUntil` vào bảng `Seats` (Phức tạp hơn vì cần reset sau mỗi lần bán)

**Đề xuất:**
```sql
CREATE TABLE SeatReservations (
    ReservationID INT PRIMARY KEY AUTO_INCREMENT,
    ShowtimeID INT NOT NULL,
    SeatID INT NOT NULL,
    StaffID INT NOT NULL, -- Nhân viên đang giữ
    LockedUntil DATETIME NOT NULL, -- Hết hạn sau X phút
    FOREIGN KEY (ShowtimeID) REFERENCES Showtimes(ShowtimeID),
    FOREIGN KEY (SeatID) REFERENCES Seats(SeatID),
    FOREIGN KEY (StaffID) REFERENCES Users(UserID)
);
```

### 2. Nghiệp vụ: Phụ thu cuối tuần / ngày lễ (Business Requirement 1.3)
**Hiện trạng:**
- Bảng `Showtimes` có `BasePrice`, nhưng chưa có cách lưu quy tắc phụ thu.

**Vấn đề:**
- Làm sao biết ngày nào là cuối tuần? Ngày lễ nào cần tăng giá?

**Giải pháp (Tùy chọn):**
- **Cách 1 (Đơn giản)**: Tính toán real-time trong code (Kiểm tra ngày nào là Thứ 7/CN).
- **Cách 2 (Nâng cao)**: Tạo bảng `PriceRules` để Admin cấu hình linh hoạt:
```sql
CREATE TABLE PriceRules (
    RuleID INT PRIMARY KEY AUTO_INCREMENT,
    RuleName VARCHAR(100), -- "Weekend Surcharge", "Holiday Surcharge"
    SurchargeType ENUM('PERCENTAGE', 'FIXED'), -- % hoặc số tiền cố định
    SurchargeValue DECIMAL(10, 2),
    ApplicableDays VARCHAR(20), -- "SAT,SUN" hoặc "2024-01-01"
    IsActive BOOLEAN DEFAULT TRUE
);
```

**Đề xuất:**
- Với quy mô hiện tại, **Cách 1** là đủ (hard-code logic vào code Java).
- Nếu muốn mở rộng sau này thì thêm bảng `PriceRules`.

### 3. Nghiệp vụ: Hủy Vé (UC09)
**Hiện trạng:**
- Bảng `Bookings` có cột `Status` (PENDING, PAID, CANCELLED).
- Bảng `Tickets` **KHÔNG CÓ** cột Status riêng.

**Vấn đề:**
- Khi hủy vé, cần đánh dấu Ticket đó là "Refunded" để biết ghế đó được giải phóng.
- Hiện tại chỉ có `Bookings.Status`, nếu hủy toàn bộ đơn hàng thì OK, nhưng nếu chỉ hủy 1 vé trong đơn hàng nhiều vé thì không xử lý được.

**Đề xuất:**
```sql
ALTER TABLE Tickets ADD COLUMN Status ENUM('ACTIVE', 'REFUNDED') DEFAULT 'ACTIVE';
```

### 4. Thiếu: Bảng lưu thông tin "Diễn viên" (Actors field)
**Hiện trạng:**
- Business Requirements đề cập: *"Nhập liệu đầy đủ: Tên phim, Đạo diễn, **Diễn viên**..."*
- Bảng `Movies` **KHÔNG CÓ** cột `Actors`.

**Đề xuất:**
- Thêm cột `Actors TEXT` vào bảng `Movies`:
```sql
ALTER TABLE Movies ADD COLUMN Actors TEXT AFTER Director;
```

### 5. Thiếu: Trường "Độ tuổi giới hạn" (Age Rating)
**Hiện trạng:**
- Business Requirements đề cập: *"Độ tuổi giới hạn (C13, C16, C18)"*
- Bảng `Movies` **KHÔNG CÓ** cột này.

**Đề xuất:**
```sql
ALTER TABLE Movies ADD COLUMN AgeRating VARCHAR(10) AFTER Genre; -- C13, C16, C18, P
```

### 6. ERD: Bảng `Payments` được khai báo nhưng chưa định nghĩa
**Hiện trạng:**
- Trong ERD có dòng: `Bookings ||--o{ Payments : transaction`
- Nhưng SQL Script **KHÔNG CÓ** câu lệnh CREATE TABLE cho `Payments`.

**Phân tích:**
- Nếu chỉ nhận tiền mặt tại quầy thì KHÔNG CẦN bảng này.
- Nếu muốn hỗ trợ nhiều phương thức thanh toán (Tiền mặt, Thẻ, Chuyển khoản) và lưu lịch sử thì **NÊN CÓ**.

**Đề xuất (Tùy chọn):**
```sql
CREATE TABLE Payments (
    PaymentID INT PRIMARY KEY AUTO_INCREMENT,
    BookingID INT NOT NULL,
    PaymentMethod ENUM('CASH', 'CARD', 'TRANSFER') NOT NULL,
    Amount DECIMAL(10, 2) NOT NULL,
    PaymentDate DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (BookingID) REFERENCES Bookings(BookingID)
);
```

---

## 📊 Checklist tổng hợp

| Chức năng | Use Case | ERD | Status |
|-----------|----------|-----|--------|
| Đăng nhập | UC01 | ✅ Users | ✅ Đủ |
| Quản lý phim | UC02 | ✅ Movies | ⚠️ Thiếu Actors, AgeRating |
| Quản lý lịch chiếu | UC03 | ✅ Showtimes | ✅ Đủ |
| Quản lý phòng/ghế | UC04 | ✅ CinemaHalls, Seats | ✅ Đủ |
| Quản lý nhân viên | UC05 | ✅ Users | ✅ Đủ |
| Báo cáo doanh thu | UC06 | ✅ Bookings, Tickets | ✅ Đủ |
| Bán vé | UC08 | ✅ Bookings, Tickets | ⚠️ Thiếu SeatReservations |
| Hủy vé | UC09 | ⚠️ Tickets | ⚠️ Thiếu Tickets.Status |
| Đăng ký thành viên | UC11 | ✅ Customers | ✅ Đủ |
| Quản lý ca | UC12 | ✅ Shifts | ✅ Đủ |
| Tính giá phụ thu | BR 1.3 | ⚠️ | ⚠️ Option: PriceRules |

---

## 🎯 Khuyến nghị

### Mức độ BẮT BUỘC phải sửa ngay:
1. ✅ Thêm cột `Actors` và `AgeRating` vào bảng `Movies`
2. ✅ Thêm cột `Status` vào bảng `Tickets` để xử lý hủy vé

### Mức độ NÊN CÓ (quan trọng cho vận hành):
3. ✅ Tạo bảng `SeatReservations` để hỗ trợ "giữ ghế tạm thời"

### Mức độ TÙY CHỌN (có thể làm sau):
4. ⚪ Xóa hoặc implement bảng `Payments` nếu cần quản lý thanh toán phức tạp
5. ⚪ Tạo bảng `PriceRules` nếu muốn Admin tự cấu hình phụ thu linh hoạt

---

## Kết luận
Hệ thống đã được thiết kế **RẤT TỐT** với 90% chức năng đã được cover bởi ERD. Chỉ cần bổ sung thêm 2-3 cột và 1 bảng `SeatReservations` là đã đủ để triển khai MVP (Minimum Viable Product).
