package com.cinema.dao;

import com.cinema.model.Member;
import com.cinema.util.DatabaseConnection;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class MemberDAO {

    public List<Member> getAllMembers() {
        List<Member> list = new ArrayList<>();
        String sql = "SELECT * FROM Members ORDER BY MemberID DESC";
        try (Connection conn = DatabaseConnection.getConnection();
                Statement stmt = conn.createStatement();
                ResultSet rs = stmt.executeQuery(sql)) {
            while (rs.next()) {
                list.add(mapResultSetToMember(rs));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return list;
    }

    public List<Member> searchMembers(String keyword) {
        List<Member> list = new ArrayList<>();
        String sql = "SELECT * FROM Members WHERE FullName LIKE ? OR PhoneNumber LIKE ?";
        try (Connection conn = DatabaseConnection.getConnection();
                PreparedStatement stmt = conn.prepareStatement(sql)) {
            String q = "%" + keyword + "%";
            stmt.setString(1, q);
            stmt.setString(2, q);
            ResultSet rs = stmt.executeQuery();
            while (rs.next()) {
                list.add(mapResultSetToMember(rs));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return list;
    }

    public boolean addMember(Member m) {
        String sql = "INSERT INTO Members (FullName, DateOfBirth, Gender, PhoneNumber, Email, Address, MembershipLevel, Points) VALUES (?, ?, ?, ?, ?, ?, ?, ?)";
        try (Connection conn = DatabaseConnection.getConnection();
                PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setString(1, m.getFullName());
            stmt.setDate(2, m.getDateOfBirth() != null ? Date.valueOf(m.getDateOfBirth()) : null);
            stmt.setString(3, m.getGender());
            stmt.setString(4, m.getPhoneNumber());
            stmt.setString(5, m.getEmail());
            stmt.setString(6, m.getAddress());
            stmt.setString(7, m.getMembershipLevel() != null ? m.getMembershipLevel() : "Standard");
            stmt.setInt(8, m.getPoints());
            return stmt.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    public boolean updateMember(Member m) {
        String sql = "UPDATE Members SET FullName=?, DateOfBirth=?, Gender=?, PhoneNumber=?, Email=?, Address=?, MembershipLevel=?, Points=? WHERE MemberID=?";
        try (Connection conn = DatabaseConnection.getConnection();
                PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setString(1, m.getFullName());
            stmt.setDate(2, m.getDateOfBirth() != null ? Date.valueOf(m.getDateOfBirth()) : null);
            stmt.setString(3, m.getGender());
            stmt.setString(4, m.getPhoneNumber());
            stmt.setString(5, m.getEmail());
            stmt.setString(6, m.getAddress());
            stmt.setString(7, m.getMembershipLevel());
            stmt.setInt(8, m.getPoints());
            stmt.setInt(9, m.getMemberId());
            return stmt.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    public boolean deleteMember(int id) {
        String sql = "DELETE FROM Members WHERE MemberID=?";
        try (Connection conn = DatabaseConnection.getConnection();
                PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, id);
            return stmt.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    // Map ResultSet to Member object
    private Member mapResultSetToMember(ResultSet rs) throws SQLException {
        Member m = new Member();
        m.setMemberId(rs.getInt("MemberID"));
        m.setFullName(rs.getString("FullName"));
        Date dob = rs.getDate("DateOfBirth");
        m.setDateOfBirth(dob != null ? dob.toLocalDate() : null);
        m.setGender(rs.getString("Gender"));
        m.setPhoneNumber(rs.getString("PhoneNumber"));
        m.setEmail(rs.getString("Email"));
        m.setAddress(rs.getString("Address"));
        m.setMembershipLevel(rs.getString("MembershipLevel"));
        m.setPoints(rs.getInt("Points"));
        Timestamp reg = rs.getTimestamp("RegistrationDate");
        m.setRegistrationDate(reg != null ? reg.toLocalDateTime() : null);
        return m;
    }
}
