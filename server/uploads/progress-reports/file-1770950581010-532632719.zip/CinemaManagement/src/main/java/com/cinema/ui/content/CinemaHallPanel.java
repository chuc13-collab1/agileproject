package com.cinema.ui.content;

import com.cinema.dao.CinemaHallDAO;
import com.cinema.model.CinemaHall;
import com.formdev.flatlaf.FlatClientProperties;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.util.List;

public class CinemaHallPanel extends JPanel {

    private JTable table;
    private DefaultTableModel tableModel;
    private CinemaHallDAO hallDAO;

    // Form Inputs
    private JTextField txtName;
    private JSpinner spinRows;
    private JSpinner spinCols;

    public CinemaHallPanel() {
        hallDAO = new CinemaHallDAO();
        initComponents();
        loadHalls();
    }

    private void initComponents() {
        setLayout(new BorderLayout(20, 20));
        setBackground(new Color(40, 42, 54));
        setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));

        // Header
        JLabel title = new JLabel("Quản Lý Phòng Chiếu");
        title.setFont(new Font("SansSerif", Font.BOLD, 24));
        title.setForeground(Color.WHITE);
        add(title, BorderLayout.NORTH);

        // --- Center: Table ---
        JPanel leftPanel = new JPanel(new BorderLayout());
        leftPanel.setOpaque(false);
        String[] cols = { "ID", "Tên Phòng", "Số Hàng", "Số Cột", "Sức Chứa" };
        tableModel = new DefaultTableModel(cols, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };

        table = new JTable(tableModel);
        table.setRowHeight(35);
        table.getTableHeader().setFont(new Font("SansSerif", Font.BOLD, 14));

        JScrollPane scroll = new JScrollPane(table);
        scroll.getViewport().setBackground(new Color(40, 42, 54));
        leftPanel.add(scroll, BorderLayout.CENTER);

        add(leftPanel, BorderLayout.CENTER);

        // --- Right: Add Form ---
        JPanel rightPanel = new JPanel();
        rightPanel.setLayout(new BoxLayout(rightPanel, BoxLayout.Y_AXIS));
        rightPanel.setBackground(new Color(50, 52, 65));
        rightPanel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));
        rightPanel.setPreferredSize(new Dimension(300, 0));

        JLabel subTitle = new JLabel("Thêm Phòng Mới");
        subTitle.setFont(new Font("SansSerif", Font.BOLD, 18));
        subTitle.setForeground(Color.WHITE);
        subTitle.setAlignmentX(Component.LEFT_ALIGNMENT);
        rightPanel.add(subTitle);
        rightPanel.add(Box.createVerticalStrut(20));

        rightPanel.add(createLabel("Tên Phòng:"));
        txtName = new JTextField();
        txtName.setMaximumSize(new Dimension(Integer.MAX_VALUE, 30));
        txtName.setAlignmentX(Component.LEFT_ALIGNMENT);
        rightPanel.add(txtName);
        rightPanel.add(Box.createVerticalStrut(15));

        rightPanel.add(createLabel("Số Hàng (Rows):"));
        spinRows = new JSpinner(new SpinnerNumberModel(8, 1, 26, 1)); // Max A-Z
        spinRows.setMaximumSize(new Dimension(Integer.MAX_VALUE, 30));
        spinRows.setAlignmentX(Component.LEFT_ALIGNMENT);
        rightPanel.add(spinRows);
        rightPanel.add(Box.createVerticalStrut(15));

        rightPanel.add(createLabel("Số Cột (Cols):"));
        spinCols = new JSpinner(new SpinnerNumberModel(10, 1, 50, 1));
        spinCols.setMaximumSize(new Dimension(Integer.MAX_VALUE, 30));
        spinCols.setAlignmentX(Component.LEFT_ALIGNMENT);
        rightPanel.add(spinCols);
        rightPanel.add(Box.createVerticalStrut(20));

        JButton btnAdd = new JButton("Tạo Phòng & Ghế");
        btnAdd.setBackground(new Color(80, 250, 123));
        btnAdd.setForeground(Color.BLACK);
        btnAdd.setAlignmentX(Component.LEFT_ALIGNMENT);
        btnAdd.addActionListener(e -> addHall());
        rightPanel.add(btnAdd);

        rightPanel.add(Box.createVerticalStrut(10));

        JButton btnDelete = new JButton("Xóa Phòng Chọn");
        btnDelete.setBackground(new Color(255, 85, 85));
        btnDelete.setForeground(Color.WHITE);
        btnDelete.setAlignmentX(Component.LEFT_ALIGNMENT);
        btnDelete.addActionListener(e -> deleteHall());
        rightPanel.add(btnDelete);

        rightPanel.add(Box.createVerticalGlue());

        add(rightPanel, BorderLayout.EAST);
    }

    private JLabel createLabel(String text) {
        JLabel l = new JLabel(text);
        l.setForeground(Color.LIGHT_GRAY);
        l.setAlignmentX(Component.LEFT_ALIGNMENT);
        return l;
    }

    private void loadHalls() {
        tableModel.setRowCount(0);
        List<CinemaHall> halls = hallDAO.getAllHalls();
        for (CinemaHall h : halls) {
            tableModel.addRow(new Object[] {
                    h.getHallId(),
                    h.getName(),
                    h.getTotalRows(),
                    h.getTotalCols(),
                    h.getTotalRows() * h.getTotalCols()
            });
        }
    }

    private void addHall() {
        String name = txtName.getText().trim();
        if (name.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Vui lòng nhập tên phòng!");
            return;
        }

        int rows = (int) spinRows.getValue();
        int cols = (int) spinCols.getValue();

        CinemaHall h = new CinemaHall();
        h.setName(name);
        h.setTotalRows(rows);
        h.setTotalCols(cols);

        if (hallDAO.addCinemaHall(h)) {
            JOptionPane.showMessageDialog(this, "Thêm thành công! Đã tự động tạo " + (rows * cols) + " ghế.");
            txtName.setText("");
            loadHalls();
        } else {
            JOptionPane.showMessageDialog(this, "Lỗi khi thêm! Có thể tên bị trùng hoặc lỗi hệ thống.");
        }
    }

    private void deleteHall() {
        int row = table.getSelectedRow();
        if (row == -1) {
            JOptionPane.showMessageDialog(this, "Chọn phòng để xóa!");
            return;
        }

        int id = (int) tableModel.getValueAt(row, 0);
        int confirm = JOptionPane.showConfirmDialog(this, "Xóa phòng này sẽ xóa toàn bộ ghế của nó.\nBạn chắc chứ?",
                "Cảnh báo", JOptionPane.YES_NO_OPTION);

        if (confirm == JOptionPane.YES_OPTION) {
            if (hallDAO.deleteCinemaHall(id)) {
                JOptionPane.showMessageDialog(this, "Đã xóa!");
                loadHalls();
            } else {
                JOptionPane.showMessageDialog(this, "Không thể xóa! Có thể phòng đang có Lịch chiếu hoặc Vé đã bán.");
            }
        }
    }
}
