package com.cinema.ui.content;

import com.cinema.dao.UserDAO;
import com.cinema.model.User;
import com.formdev.flatlaf.FlatClientProperties;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.util.List;

public class StaffManagementPanel extends JPanel {

    private JTable table;
    private DefaultTableModel tableModel;
    private UserDAO userDAO;

    public StaffManagementPanel() {
        this.userDAO = new UserDAO();
        initComponents();
        loadUsers();
    }

    private void initComponents() {
        setLayout(new BorderLayout(20, 20));
        setBackground(new Color(40, 42, 54));
        setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));

        // Header
        JPanel header = new JPanel(new BorderLayout());
        header.setOpaque(false);
        JLabel title = new JLabel("Quản Lý Nhân Viên");
        title.setFont(new Font("SansSerif", Font.BOLD, 24));
        title.setForeground(Color.WHITE);
        header.add(title, BorderLayout.WEST);

        // Toolbar
        JPanel toolbar = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        toolbar.setOpaque(false);

        JButton btnRefresh = new JButton("Làm mới");
        btnRefresh.addActionListener(e -> loadUsers());

        JButton btnAdd = new JButton("Thêm Nhân Viên");
        btnAdd.setBackground(new Color(80, 250, 123));
        btnAdd.setForeground(Color.BLACK);
        btnAdd.addActionListener(e -> showUserDialog(null));

        JButton btnEdit = new JButton("Sửa");
        btnEdit.addActionListener(e -> {
            User u = getSelectedUser();
            if (u != null)
                showUserDialog(u);
        });

        JButton btnResetPass = new JButton("Reset Mật Khẩu");
        btnResetPass.setBackground(new Color(255, 184, 108)); // Orange
        btnResetPass.setForeground(Color.BLACK);
        btnResetPass.addActionListener(e -> resetPassword());

        JButton btnDelete = new JButton("Xóa");
        btnDelete.setBackground(new Color(255, 85, 85)); // Red
        btnDelete.setForeground(Color.WHITE);
        btnDelete.addActionListener(e -> deleteUser());

        toolbar.add(btnRefresh);
        toolbar.add(Box.createHorizontalStrut(20));
        toolbar.add(btnAdd);
        toolbar.add(btnEdit);
        toolbar.add(btnResetPass);
        toolbar.add(btnDelete);

        header.add(toolbar, BorderLayout.EAST);
        add(header, BorderLayout.NORTH);

        // Table
        String[] cols = { "ID", "Tên Đăng Nhập", "Họ Tên", "Vai Trò", "Trạng Thái" };
        tableModel = new DefaultTableModel(cols, 0) {
            @Override
            public boolean isCellEditable(int row, int col) {
                return false;
            }
        };
        table = new JTable(tableModel);
        table.setRowHeight(30);

        JScrollPane scroll = new JScrollPane(table);
        scroll.getViewport().setBackground(new Color(40, 42, 54));
        add(scroll, BorderLayout.CENTER);
    }

    private void loadUsers() {
        tableModel.setRowCount(0);
        List<User> list = userDAO.getAllUsers();
        for (User u : list) {
            tableModel.addRow(new Object[] {
                    u.getUserId(),
                    u.getUsername(),
                    u.getFullName(),
                    u.getRole(),
                    u.isActive() ? "Hoạt động" : "Khóa"
            });
        }
    }

    private User getSelectedUser() {
        int r = table.getSelectedRow();
        if (r == -1) {
            JOptionPane.showMessageDialog(this, "Vui lòng chọn nhân viên!", "Thông báo", JOptionPane.WARNING_MESSAGE);
            return null;
        }
        int id = (int) tableModel.getValueAt(r, 0);
        // Find user by ID in loaded check or re-fetch?
        // Since we didn't add getById to DAO, iterate via getAllUsers is simplest for
        // small list
        // Or cleaner: add getById. But for now I'll trust the table data + simple DAO
        // logic.
        // Actually, just fetching all again or filtering.
        // Let's iterate userDAO.getAllUsers() to match ID.
        return userDAO.getAllUsers().stream().filter(u -> u.getUserId() == id).findFirst().orElse(null);
    }

    // Dialog for Add and Edit
    private void showUserDialog(User user) {
        JDialog d = new JDialog((Frame) SwingUtilities.getWindowAncestor(this),
                user == null ? "Thêm Nhân Viên Mới" : "Sửa Thông Tin", true);
        d.setLayout(new GridBagLayout());
        d.setSize(400, 400);
        d.setLocationRelativeTo(this);

        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(10, 10, 10, 10);
        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.gridx = 0;
        gbc.gridy = 0;

        JTextField txtUsername = new JTextField(20);
        JPasswordField txtPass = new JPasswordField(20);
        JTextField txtFullname = new JTextField(20);
        JComboBox<String> cbRole = new JComboBox<>(new String[] { "STAFF", "ADMIN" });
        JCheckBox chkActive = new JCheckBox("Đang hoạt động");
        chkActive.setSelected(true);

        // Editing Mode
        if (user != null) {
            txtUsername.setText(user.getUsername());
            txtUsername.setEditable(false); // Cannot change username
            txtFullname.setText(user.getFullName());
            cbRole.setSelectedItem(user.getRole());
            chkActive.setSelected(user.isActive());
        }

        d.add(new JLabel("Tên đăng nhập:"), gbc);
        gbc.gridx = 1;
        d.add(txtUsername, gbc);

        // Only show password field for NEW users
        if (user == null) {
            gbc.gridx = 0;
            gbc.gridy++;
            d.add(new JLabel("Mật khẩu:"), gbc);
            gbc.gridx = 1;
            d.add(txtPass, gbc);
        }

        gbc.gridx = 0;
        gbc.gridy++;
        d.add(new JLabel("Họ tên:"), gbc);
        gbc.gridx = 1;
        d.add(txtFullname, gbc);
        gbc.gridx = 0;
        gbc.gridy++;
        d.add(new JLabel("Vai trò:"), gbc);
        gbc.gridx = 1;
        d.add(cbRole, gbc);
        gbc.gridx = 0;
        gbc.gridy++;
        d.add(new JLabel("Trạng thái:"), gbc);
        gbc.gridx = 1;
        d.add(chkActive, gbc);

        JPanel btnP = new JPanel();
        JButton btnSave = new JButton("Lưu");
        JButton btnCancel = new JButton("Hủy");
        btnP.add(btnSave);
        btnP.add(btnCancel);

        gbc.gridx = 0;
        gbc.gridy++;
        gbc.gridwidth = 2;
        d.add(btnP, gbc);

        btnCancel.addActionListener(e -> d.dispose());
        btnSave.addActionListener(e -> {
            String uName = txtUsername.getText().trim();
            String fName = txtFullname.getText().trim();
            String pass = new String(txtPass.getPassword());

            if (uName.isEmpty() || fName.isEmpty() || (user == null && pass.isEmpty())) {
                JOptionPane.showMessageDialog(d, "Vui lòng điền đầy đủ thông tin!");
                return;
            }

            boolean success;
            if (user == null) {
                // Add
                User newUser = new User();
                newUser.setUsername(uName);
                newUser.setFullName(fName);
                newUser.setRole((String) cbRole.getSelectedItem());
                newUser.setActive(chkActive.isSelected());
                success = userDAO.addUser(newUser, pass);
            } else {
                // Update
                user.setFullName(fName);
                user.setRole((String) cbRole.getSelectedItem());
                user.setActive(chkActive.isSelected());
                success = userDAO.updateUser(user);
            }

            if (success) {
                JOptionPane.showMessageDialog(d, "Lưu thành công!");
                d.dispose();
                loadUsers();
            } else {
                JOptionPane.showMessageDialog(d, "Lỗi khi lưu! (Có thể tên đăng nhập đã tồn tại)");
            }
        });

        d.setVisible(true);
    }

    private void resetPassword() {
        User u = getSelectedUser();
        if (u == null)
            return;

        String newPass = JOptionPane.showInputDialog(this, "Nhập mật khẩu mới cho " + u.getUsername() + ":");
        if (newPass != null && !newPass.trim().isEmpty()) {
            if (userDAO.resetPassword(u.getUserId(), newPass)) {
                JOptionPane.showMessageDialog(this, "Đã đổi mật khẩu thành công!");
            } else {
                JOptionPane.showMessageDialog(this, "Lỗi khi đổi mật khẩu!");
            }
        }
    }

    private void deleteUser() {
        User u = getSelectedUser();
        if (u != null) {
            int cf = JOptionPane.showConfirmDialog(this, "Bạn CÓ CHẮC muốn xóa tài khoản: " + u.getUsername() + "?");
            if (cf == JOptionPane.YES_OPTION) {
                if (userDAO.deleteUser(u.getUserId())) {
                    loadUsers();
                } else {
                    JOptionPane.showMessageDialog(this, "Lỗi khi xóa!");
                }
            }
        }
    }
}
