package com.cinema.ui;

import com.cinema.model.User;
import com.cinema.service.AuthService;
import com.formdev.flatlaf.FlatClientProperties;

import javax.imageio.ImageIO;
import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.geom.RoundRectangle2D;
import java.io.File;
import java.io.IOException;

/**
 * Login screen with Netflix-inspired design
 */
public class LoginFrame extends JFrame {

    private JTextField usernameField;
    private JPasswordField passwordField;
    private JButton loginButton;
    private AuthService authService;
    private Image backgroundImage;

    public LoginFrame() {
        this.authService = new AuthService();
        loadBackgroundImage();
        initComponents();
    }

    private void loadBackgroundImage() {
        try {
            // Load from classpath (works for JAR)
            java.net.URL imgUrl = getClass().getResource("/images/login_bg.jpg");
            if (imgUrl != null) {
                backgroundImage = ImageIO.read(imgUrl);
            } else {
                // Fallback or dev mode check
                File imgFile = new File("media/posters/ec80a6378f9b21d149bdacbba282f584.jpg");
                if (imgFile.exists()) {
                    backgroundImage = ImageIO.read(imgFile);
                } else {
                    System.out.println("Background image not found in resources or local path.");
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private void initComponents() {
        setTitle("Cinema Management System");
        setSize(1000, 700);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        // Custom Content Pane for Background
        setContentPane(new JPanel() {
            @Override
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                Graphics2D g2d = (Graphics2D) g;

                // 1. Draw Background Image
                if (backgroundImage != null) {
                    g2d.drawImage(backgroundImage, 0, 0, getWidth(), getHeight(), this);
                } else {
                    g2d.setColor(Color.BLACK);
                    g2d.fillRect(0, 0, getWidth(), getHeight());
                }

                // 2. Draw Dark Overlay (Gradient or Solid)
                GradientPaint gp = new GradientPaint(
                        0, 0, new Color(0, 0, 0, 120),
                        0, getHeight(), new Color(0, 0, 0, 200));
                g2d.setPaint(gp);
                g2d.fillRect(0, 0, getWidth(), getHeight());
            }
        });
        setLayout(new GridBagLayout()); // To center the login card

        // Login Card Panel
        JPanel loginCard = new JPanel() {
            @Override
            protected void paintComponent(Graphics g) {
                // Semi-transparent black background
                Graphics2D g2d = (Graphics2D) g.create();
                g2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                g2d.setColor(new Color(0, 0, 0, 190)); // Black with 75% opacity
                g2d.fill(new RoundRectangle2D.Double(0, 0, getWidth(), getHeight(), 10, 10));
                g2d.dispose();
            }
        };
        loginCard.setOpaque(false);
        loginCard.setLayout(new BoxLayout(loginCard, BoxLayout.Y_AXIS));
        loginCard.setBorder(new EmptyBorder(50, 60, 50, 60));
        loginCard.setPreferredSize(new Dimension(450, 550));
        loginCard.setMinimumSize(new Dimension(450, 550));

        // 1. "Sign In" Title
        JLabel titleLabel = new JLabel("Đăng Nhập");
        titleLabel.setForeground(Color.WHITE);
        titleLabel.setFont(new Font("SansSerif", Font.BOLD, 32));
        titleLabel.setAlignmentX(Component.LEFT_ALIGNMENT);

        // 2. Username Field
        usernameField = new JTextField();
        styleTextField(usernameField, "Tên đăng nhập");

        // 3. Password Field
        passwordField = new JPasswordField();
        styleTextField(passwordField, "Mật khẩu");
        passwordField.putClientProperty(FlatClientProperties.STYLE, "showRevealButton: true");

        // 4. "Sign In" Button
        loginButton = new JButton("Đăng Nhập");
        loginButton.setFont(new Font("SansSerif", Font.BOLD, 16));
        loginButton.setForeground(Color.WHITE);
        loginButton.setBackground(new Color(229, 9, 20)); // Netflix Red
        loginButton.setOpaque(true);
        loginButton.setBorderPainted(false);
        loginButton.setFocusPainted(false);
        loginButton.setCursor(new Cursor(Cursor.HAND_CURSOR));
        loginButton.setMaximumSize(new Dimension(Integer.MAX_VALUE, 50));
        loginButton.setAlignmentX(Component.LEFT_ALIGNMENT);
        loginButton.addActionListener(this::handleLogin);

        // 5. "Remember me" & "Need help?"
        JPanel helpPanel = new JPanel(new BorderLayout());
        helpPanel.setOpaque(false);
        helpPanel.setMaximumSize(new Dimension(Integer.MAX_VALUE, 30));
        helpPanel.setAlignmentX(Component.LEFT_ALIGNMENT);

        JCheckBox rememberMe = new JCheckBox("Ghi nhớ đăng nhập");
        rememberMe.setForeground(new Color(179, 179, 179));
        rememberMe.setOpaque(false);
        rememberMe.setFont(new Font("SansSerif", Font.PLAIN, 13));

        JLabel needHelp = new JLabel("Cần trợ giúp?");
        needHelp.setForeground(new Color(179, 179, 179));
        needHelp.setFont(new Font("SansSerif", Font.PLAIN, 13));

        helpPanel.add(rememberMe, BorderLayout.WEST);
        helpPanel.add(needHelp, BorderLayout.EAST);

        // 6. Sign up text
        JLabel newToAppText = new JLabel("Chưa có tài khoản? Liên hệ Admin.");
        newToAppText.setForeground(new Color(115, 115, 115));
        newToAppText.setFont(new Font("SansSerif", Font.PLAIN, 15));
        newToAppText.setAlignmentX(Component.LEFT_ALIGNMENT);

        // Add components to card
        loginCard.add(titleLabel);
        loginCard.add(Box.createVerticalStrut(30));
        loginCard.add(usernameField);
        loginCard.add(Box.createVerticalStrut(15));
        loginCard.add(passwordField);
        loginCard.add(Box.createVerticalStrut(40));
        loginCard.add(loginButton);
        loginCard.add(Box.createVerticalStrut(15));
        loginCard.add(helpPanel);
        loginCard.add(Box.createVerticalStrut(40));
        loginCard.add(newToAppText);
        loginCard.add(Box.createVerticalGlue()); // Push content up

        // Add card to main frame (centered by GridBagLayout default)
        add(loginCard);

        // Allow Enter key to submit
        getRootPane().setDefaultButton(loginButton);
    }

    private void styleTextField(JTextField field, String placeholder) {
        field.putClientProperty(FlatClientProperties.PLACEHOLDER_TEXT, placeholder);
        field.putClientProperty(FlatClientProperties.STYLE,
                "arc: 5; " +
                        "margin: 0,15,0,15; " +
                        "borderWidth: 0; " +
                        "focusWidth: 0; " +
                        "innerFocusWidth: 0; " +
                        "background: #333333; " +
                        "foreground: #FFFFFF; " +
                        "placeholderForeground: #8c8c8c");
        field.setFont(new Font("SansSerif", Font.PLAIN, 16));
        field.setCaretColor(Color.WHITE);
        field.setMaximumSize(new Dimension(Integer.MAX_VALUE, 50));
        field.setAlignmentX(Component.LEFT_ALIGNMENT);
    }

    private void handleLogin(ActionEvent e) {
        String username = usernameField.getText().trim();
        String password = new String(passwordField.getPassword());

        if (username.isEmpty() || password.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Vui lòng nhập tên đăng nhập và mật khẩu.", "Cảnh báo",
                    JOptionPane.WARNING_MESSAGE);
            return;
        }

        try {
            User user = authService.login(username, password);
            if (user != null) {
                // Success
                this.dispose(); // Close login window
                new MainFrame(user).setVisible(true); // Open Main Frame with User
            } else {
                JOptionPane.showMessageDialog(this, "Sai tên đăng nhập hoặc mật khẩu!", "Đăng nhập thất bại",
                        JOptionPane.ERROR_MESSAGE);
            }
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this, "Lỗi kết nối CSDL: " + ex.getMessage(), "Lỗi",
                    JOptionPane.ERROR_MESSAGE);
            ex.printStackTrace();
        }
    }
}
