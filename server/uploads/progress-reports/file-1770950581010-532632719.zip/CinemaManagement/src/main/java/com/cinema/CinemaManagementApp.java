package com.cinema;

import com.cinema.ui.LoginFrame;
import com.cinema.util.DatabaseConnection;
import com.formdev.flatlaf.FlatDarkLaf;
import javax.swing.SwingUtilities;
import java.sql.Connection;
import java.sql.SQLException;

public class CinemaManagementApp {

    public static void main(String[] args) {
        System.out.println("Starting Cinema Management System...");

        // Ensure Database Schema is up to date
        com.cinema.util.SchemaMigration.main(null);

        // Setup FlatLaf
        FlatDarkLaf.setup();

        SwingUtilities.invokeLater(() -> {
            try {
                // Test Database Connection
                Connection conn = DatabaseConnection.getConnection();

                if (conn != null) {
                    System.out.println("Started App: Database Connected.");
                    // Run cleanup to remove duplicates (Movies + Showtimes)
                    // com.cinema.util.DataCleanup.main(args);

                    // Fix missing seats
                    // com.cinema.util.FixSeatData.main(args);
                }

                // Show Login Screen
                new LoginFrame().setVisible(true);

            } catch (SQLException e) {
                System.err.println("Fatal Error: Cannot connect to database.");
                e.printStackTrace();
                // Show error dialog
                javax.swing.JOptionPane.showMessageDialog(null,
                        "Cannot connect to database.\n" + e.getMessage(),
                        "Database Error",
                        javax.swing.JOptionPane.ERROR_MESSAGE);
            }
        });
    }
}
