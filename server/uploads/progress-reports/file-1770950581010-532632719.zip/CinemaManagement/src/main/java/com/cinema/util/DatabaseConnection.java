package com.cinema.util;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class DatabaseConnection {

    private static Connection connection;
    // Database file will be created in the application execution directory
    private static final String URL = "jdbc:sqlite:cinema.db";

    private DatabaseConnection() {
    }

    public static Connection getConnection() throws SQLException {
        if (connection == null || connection.isClosed()) {
            try {
                // Load SQLite JDBC Driver
                Class.forName("org.sqlite.JDBC");
                connection = DriverManager.getConnection(URL);
                System.out.println("Connected to SQLite database: cinema.db");
            } catch (ClassNotFoundException e) {
                throw new SQLException("SQLite Driver not found: " + e.getMessage());
            }
        }
        return connection;
    }

    // Test connection
    public static void main(String[] args) {
        try {
            Connection conn = DatabaseConnection.getConnection();
            if (conn != null) {
                System.out.println("Connection test passed!");
                conn.close();
            }
        } catch (SQLException e) {
            System.err.println("Connection test failed!");
            e.printStackTrace();
        }
    }
}
