package com.cinema.ui.content;

import com.cinema.dao.CinemaHallDAO;
import com.cinema.dao.MovieDAO;
import com.cinema.dao.ShowtimeDAO;
import com.cinema.model.CinemaHall;
import com.cinema.model.Movie;
import com.cinema.model.Showtime;
import com.cinema.ui.MainFrame;
import com.formdev.flatlaf.FlatClientProperties;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.io.File;
import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.List;
import javax.imageio.ImageIO;

public class SchedulePanel extends JPanel {

    private JTable table;
    private DefaultTableModel tableModel;
    private ShowtimeDAO showtimeDAO;
    private MovieDAO movieDAO;
    private CinemaHallDAO hallDAO;
    private MainFrame mainFrame;

    // Form components
    private JComboBox<Movie> cmbMovies;
    private JComboBox<CinemaHall> cmbHalls;
    private JSpinner spinDate; // For Date and Time selection
    private JTextField txtPrice;

    // Formatter
    private DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm");
    private DateTimeFormatter justTime = DateTimeFormatter.ofPattern("HH:mm");

    public SchedulePanel(MainFrame mainFrame) {
        this.mainFrame = mainFrame;
        showtimeDAO = new ShowtimeDAO();
        movieDAO = new MovieDAO();
        hallDAO = new CinemaHallDAO();

        initComponents();
        loadShowtimes();
    }

    public SchedulePanel() {
        this(null);
    }

    private void initComponents() {
        setLayout(new BorderLayout(10, 10));
        setBackground(new Color(40, 42, 54));
        setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));

        // --- Left Side: List ---
        JPanel listPanel = new JPanel(new BorderLayout());
        listPanel.setOpaque(false);

        JLabel title = new JLabel("Danh sách Lịch Chiếu");
        title.setFont(new Font("SansSerif", Font.BOLD, 22));
        title.setForeground(Color.WHITE);
        listPanel.add(title, BorderLayout.NORTH);

        String[] cols = { "ID", "Phim", "Phòng", "Bắt đầu", "Kết thúc", "Giá vé" };
        tableModel = new DefaultTableModel(cols, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };
        table = new JTable(tableModel);
        table.setRowHeight(30);

        // Add Selection Listener
        table.getSelectionModel().addListSelectionListener(e -> {
            if (!e.getValueIsAdjusting() && table.getSelectedRow() != -1) {
                updateSidebarWithSelection();
            }
        });

        table.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                updateSidebarWithSelection();
            }
        });

        JScrollPane scroll = new JScrollPane(table);
        listPanel.add(scroll, BorderLayout.CENTER);

        // --- Right Side: Form ---
        JPanel formPanel = new JPanel();
        formPanel.setLayout(new BoxLayout(formPanel, BoxLayout.Y_AXIS));
        formPanel.setBackground(new Color(50, 52, 65));
        formPanel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));
        formPanel.setPreferredSize(new Dimension(350, 0));

        JLabel formTitle = new JLabel("Thêm Suất Chiếu");
        formTitle.setFont(new Font("SansSerif", Font.BOLD, 18));
        formTitle.setForeground(Color.WHITE);
        formTitle.setAlignmentX(Component.LEFT_ALIGNMENT);
        formPanel.add(formTitle);
        formPanel.add(Box.createVerticalStrut(20));

        // Movie Select
        formPanel.add(createLabel("Chọn Phim:"));
        cmbMovies = new JComboBox<>();
        loadMoviesCombo();
        formPanel.add(cmbMovies);
        formPanel.add(Box.createVerticalStrut(15));

        // Hall Select
        formPanel.add(createLabel("Chọn Phòng:"));
        cmbHalls = new JComboBox<>();
        loadHallsCombo();
        formPanel.add(cmbHalls);
        formPanel.add(Box.createVerticalStrut(15));

        // Date Time Select
        formPanel.add(createLabel("Thời gian bắt đầu:"));
        spinDate = new JSpinner(new SpinnerDateModel());
        JSpinner.DateEditor timeEditor = new JSpinner.DateEditor(spinDate, "yyyy-MM-dd HH:mm");
        spinDate.setEditor(timeEditor);
        spinDate.setValue(new java.util.Date()); // Now
        spinDate.setAlignmentX(Component.LEFT_ALIGNMENT);
        spinDate.setMaximumSize(new Dimension(Integer.MAX_VALUE, 30));
        formPanel.add(spinDate);
        formPanel.add(Box.createVerticalStrut(15));

        // Price
        formPanel.add(createLabel("Giá vé (VNĐ):"));
        txtPrice = new JTextField("50000");
        txtPrice.setAlignmentX(Component.LEFT_ALIGNMENT);
        txtPrice.setMaximumSize(new Dimension(Integer.MAX_VALUE, 30));
        formPanel.add(txtPrice);
        formPanel.add(Box.createVerticalStrut(20));

        // Buttons
        JButton btnAdd = new JButton("Thêm Lịch");
        btnAdd.setBackground(new Color(80, 250, 123));
        btnAdd.setForeground(Color.BLACK);
        btnAdd.setAlignmentX(Component.LEFT_ALIGNMENT);

        JButton btnDelete = new JButton("Xóa Lịch Chọn");
        btnDelete.setBackground(new Color(255, 85, 85));
        btnDelete.setForeground(Color.WHITE);
        btnDelete.setAlignmentX(Component.LEFT_ALIGNMENT);

        JButton btnRefresh = new JButton("Làm mới / Reset");
        btnRefresh.setBackground(new Color(98, 114, 164));
        btnRefresh.setForeground(Color.WHITE);
        btnRefresh.setAlignmentX(Component.LEFT_ALIGNMENT);

        btnAdd.addActionListener(e -> addShowtime());
        btnDelete.addActionListener(e -> deleteShowtime());
        btnRefresh.addActionListener(e -> {
            loadShowtimes();
            if (mainFrame != null)
                mainFrame.resetRightSidebar();
        });

        formPanel.add(btnAdd);
        formPanel.add(Box.createVerticalStrut(10));
        formPanel.add(btnDelete);
        formPanel.add(Box.createVerticalStrut(10));
        formPanel.add(btnRefresh);
        formPanel.add(Box.createVerticalGlue());

        add(listPanel, BorderLayout.CENTER);
        add(formPanel, BorderLayout.EAST);
    }

    private JLabel createLabel(String text) {
        JLabel l = new JLabel(text);
        l.setForeground(Color.LIGHT_GRAY);
        l.setAlignmentX(Component.LEFT_ALIGNMENT);
        return l;
    }

    private void updateSidebarWithSelection() {
        if (mainFrame == null)
            return;

        int row = table.getSelectedRow();
        if (row != -1) {
            // Get basic info from table first
            int showtimeId = (int) tableModel.getValueAt(row, 0);
            String title = (String) tableModel.getValueAt(row, 1);
            String hallName = (String) tableModel.getValueAt(row, 2);
            String startTimeStr = (String) tableModel.getValueAt(row, 3);
            String price = String.valueOf(tableModel.getValueAt(row, 5));

            // To show poster, we need to find the movie object associated.
            // Since table doesn't have MovieID, let's find it from showtimeDAO list or
            // fetch again.
            // Fetching a single showtime or iterating our loaded list is best.
            // Let's just iterate existing list in memory to avoid extra DB call if
            // possible,
            // but we don't keep the list in memory class field currently.
            // Let's fetch the showtime details by ID or find from movies.
            // We have movieDAO. Let's find movie by Title (might be duplicate titles
            // though).
            // Better: Store list<Showtime> in class.

            // Re-fetch all showtimes to find the one. Simple for now.
            List<Showtime> list = showtimeDAO.getAllShowtimes();
            Showtime selected = list.stream().filter(s -> s.getShowtimeId() == showtimeId).findFirst().orElse(null);

            if (selected != null) {
                // Get Movie for Poster
                List<Movie> movies = movieDAO.getAllMovies();
                Movie m = movies.stream().filter(mov -> mov.getMovieId() == selected.getMovieId()).findFirst()
                        .orElse(null);

                mainFrame.setRightSidebarContent(createDetailPanel(selected, m));
            }
        }
    }

    private JPanel createDetailPanel(Showtime s, Movie m) {
        JPanel panel = new JPanel();
        panel.setLayout(new BoxLayout(panel, BoxLayout.Y_AXIS));
        panel.setOpaque(false);

        // Poster
        ImageIcon icon = null;
        if (m != null && m.getPosterPath() != null) {
            try {
                Image image = null;
                if (m.getPosterPath().startsWith("http")) {
                    image = ImageIO.read(new java.net.URL(m.getPosterPath()));
                } else {
                    File imgFile = new File(m.getPosterPath());
                    if (imgFile.exists()) {
                        image = ImageIO.read(imgFile);
                    }
                }

                if (image != null) {
                    Image scaled = image.getScaledInstance(180, 250, Image.SCALE_SMOOTH);
                    icon = new ImageIcon(scaled);
                }
            } catch (Exception ex) {
            }
        }

        JLabel posterLabel = new JLabel();
        if (icon != null) {
            posterLabel.setIcon(icon);
        } else {
            posterLabel.setPreferredSize(new Dimension(180, 250));
            posterLabel.setBorder(BorderFactory.createLineBorder(Color.GRAY));
            posterLabel.setText("NO POSTER");
            posterLabel.setForeground(Color.GRAY);
            posterLabel.setHorizontalAlignment(SwingConstants.CENTER);
        }
        posterLabel.setAlignmentX(Component.CENTER_ALIGNMENT);
        panel.add(posterLabel);

        panel.add(Box.createVerticalStrut(20));

        // Movie Title
        JLabel titleLabel = new JLabel(
                "<html><div style='text-align: center;'>" + (m != null ? m.getTitle() : "Unknown") + "</div></html>");
        titleLabel.setFont(new Font("SansSerif", Font.BOLD, 20));
        titleLabel.setForeground(Color.WHITE);
        titleLabel.setAlignmentX(Component.CENTER_ALIGNMENT);
        panel.add(titleLabel);

        panel.add(Box.createVerticalStrut(10));

        // Showtime Info Card
        JPanel card = new JPanel();
        card.setLayout(new BoxLayout(card, BoxLayout.Y_AXIS));
        card.setBackground(new Color(60, 63, 65));
        card.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
        card.setAlignmentX(Component.CENTER_ALIGNMENT);

        addInfoRow(card, "Phòng:", s.getHallName());
        addInfoRow(card, "Ngày:", s.getStartTime().toLocalDate().toString());
        addInfoRow(card, "Giờ:", s.getStartTime().format(justTime) + " - " + s.getEndTime().format(justTime));
        addInfoRow(card, "Giá vé:", s.getBasePrice() + " đ");

        panel.add(card);

        return panel;
    }

    private void addInfoRow(JPanel p, String label, String value) {
        JPanel row = new JPanel(new BorderLayout());
        row.setOpaque(false);
        row.setMaximumSize(new Dimension(250, 30));
        JLabel l = new JLabel(label);
        l.setForeground(Color.GRAY);
        JLabel v = new JLabel(value);
        v.setForeground(Color.CYAN);
        v.setFont(new Font("SansSerif", Font.BOLD, 14));

        row.add(l, BorderLayout.WEST);
        row.add(v, BorderLayout.EAST);
        p.add(row);
        p.add(Box.createVerticalStrut(5));
    }

    private void loadMoviesCombo() {
        cmbMovies.removeAllItems();
        List<Movie> movies = movieDAO.getAllMovies();
        for (Movie m : movies) {
            cmbMovies.addItem(m);
        }
    }

    private void loadHallsCombo() {
        cmbHalls.removeAllItems();
        List<CinemaHall> halls = hallDAO.getAllHalls();
        for (CinemaHall h : halls) {
            cmbHalls.addItem(h);
        }
    }

    private void loadShowtimes() {
        tableModel.setRowCount(0);
        List<Showtime> list = showtimeDAO.getAllShowtimes();
        for (Showtime s : list) {
            tableModel.addRow(new Object[] {
                    s.getShowtimeId(),
                    s.getMovieTitle(),
                    s.getHallName(),
                    s.getStartTime().format(dtf),
                    s.getEndTime().format(dtf),
                    s.getBasePrice()
            });
        }
    }

    private void addShowtime() {
        try {
            Movie selectedMovie = (Movie) cmbMovies.getSelectedItem();
            CinemaHall selectedHall = (CinemaHall) cmbHalls.getSelectedItem();

            if (selectedMovie == null || selectedHall == null) {
                JOptionPane.showMessageDialog(this, "Vui lòng chọn phim và phòng!");
                return;
            }

            java.util.Date dateVal = (java.util.Date) spinDate.getValue();
            LocalDateTime startTime = new java.sql.Timestamp(dateVal.getTime()).toLocalDateTime();

            // Calculate EndTime
            LocalDateTime endTime = startTime.plusMinutes(selectedMovie.getDuration() + 15); // +15 mins cleaning

            // Check Conflict
            if (showtimeDAO.checkOverlap(selectedHall.getHallId(), startTime, endTime)) {
                JOptionPane.showMessageDialog(this, "⚠️ Xung đột lịch chiếu! Phòng này đã có lịch trong khung giờ đó.");
                return;
            }

            BigDecimal price = new BigDecimal(txtPrice.getText());

            Showtime s = new Showtime();
            s.setMovieId(selectedMovie.getMovieId());
            s.setHallId(selectedHall.getHallId());
            s.setStartTime(startTime);
            s.setEndTime(endTime);
            s.setBasePrice(price);

            if (showtimeDAO.addShowtime(s)) {
                JOptionPane.showMessageDialog(this, "Thêm lịch thành công!");
                loadShowtimes();
            } else {
                JOptionPane.showMessageDialog(this, "Lỗi khi lưu vào CSDL");
            }

        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Dữ liệu không hợp lệ: " + e.getMessage());
        }
    }

    private void deleteShowtime() {
        int row = table.getSelectedRow();
        if (row == -1)
            return;

        int id = (int) tableModel.getValueAt(row, 0);
        if (showtimeDAO.deleteShowtime(id)) {
            loadShowtimes();
        } else {
            JOptionPane.showMessageDialog(this, "Xóa thất bại");
        }
    }
}
