package com.cinema.dao;

import com.cinema.util.DatabaseConnection;
import java.math.BigDecimal;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

public class ReportDAO {

    // DTO for Movie Revenue
    public static class MovieRevenue {
        private String movieTitle;
        private int ticketsSold;
        private BigDecimal totalRevenue;

        public MovieRevenue(String title, int count, BigDecimal rev) {
            this.movieTitle = title;
            this.ticketsSold = count;
            this.totalRevenue = rev;
        }

        // Getters
        public String getMovieTitle() {
            return movieTitle;
        }

        public int getTicketsSold() {
            return ticketsSold;
        }

        public BigDecimal getTotalRevenue() {
            return totalRevenue;
        }
    }

    // DTO for Daily Revenue
    public static class DailyRevenue {
        private LocalDate date;
        private int bookingCount;
        private BigDecimal totalRevenue;

        public DailyRevenue(LocalDate d, int c, BigDecimal r) {
            this.date = d;
            this.bookingCount = c;
            this.totalRevenue = r;
        }

        public LocalDate getDate() {
            return date;
        }

        public int getBookingCount() {
            return bookingCount;
        }

        public BigDecimal getTotalRevenue() {
            return totalRevenue;
        }
    }

    public List<MovieRevenue> getRevenueByMovie(LocalDate from, LocalDate to) {
        List<MovieRevenue> list = new ArrayList<>();
        // Query joins Tickets, Showtimes, Movies, Bookings
        // Filter by Date Range and Status=PAID
        String sql = "SELECT m.Title, COUNT(t.TicketID) as SoldCount, SUM(t.Price) as Revenue " +
                "FROM Tickets t " +
                "JOIN Showtimes s ON t.ShowtimeID = s.ShowtimeID " +
                "JOIN Movies m ON s.MovieID = m.MovieID " +
                "JOIN Bookings b ON t.BookingID = b.BookingID " +
                "WHERE b.Status = 'PAID' ";

        if (from != null)
            sql += " AND DATE(b.BookingDate) >= ? ";
        if (to != null)
            sql += " AND DATE(b.BookingDate) <= ? ";

        sql += " GROUP BY m.Title ORDER BY Revenue DESC";

        try (Connection conn = DatabaseConnection.getConnection();
                PreparedStatement stmt = conn.prepareStatement(sql)) {

            int idx = 1;
            if (from != null)
                stmt.setDate(idx++, java.sql.Date.valueOf(from));
            if (to != null)
                stmt.setDate(idx++, java.sql.Date.valueOf(to));

            ResultSet rs = stmt.executeQuery();
            while (rs.next()) {
                list.add(new MovieRevenue(
                        rs.getString("Title"),
                        rs.getInt("SoldCount"),
                        rs.getBigDecimal("Revenue")));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return list;
    }

    public List<DailyRevenue> getDailyRevenue(LocalDate from, LocalDate to) {
        List<DailyRevenue> list = new ArrayList<>();
        String sql = "SELECT DATE(BookingDate) as RevDate, COUNT(BookingID) as Cnt, SUM(TotalAmount) as Total " +
                "FROM Bookings " +
                "WHERE Status = 'PAID' ";

        if (from != null)
            sql += " AND DATE(BookingDate) >= ? ";
        if (to != null)
            sql += " AND DATE(BookingDate) <= ? ";

        sql += " GROUP BY DATE(BookingDate) ORDER BY RevDate DESC";

        try (Connection conn = DatabaseConnection.getConnection();
                PreparedStatement stmt = conn.prepareStatement(sql)) {

            int idx = 1;
            if (from != null)
                stmt.setDate(idx++, java.sql.Date.valueOf(from));
            if (to != null)
                stmt.setDate(idx++, java.sql.Date.valueOf(to));

            ResultSet rs = stmt.executeQuery();
            while (rs.next()) {
                list.add(new DailyRevenue(
                        rs.getDate("RevDate").toLocalDate(),
                        rs.getInt("Cnt"),
                        rs.getBigDecimal("Total")));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return list;
    }
}
