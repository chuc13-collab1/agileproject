package com.cinema.service;

import com.cinema.dao.UserDAO;
import com.cinema.model.User;
import org.mindrot.jbcrypt.BCrypt;

/**
 * Service class for Authentication logic
 */
public class AuthService {

    private UserDAO userDAO;
    private User currentUser;

    public AuthService() {
        this.userDAO = new UserDAO();
    }

    /**
     * Authenticate user by username and password
     * 
     * @param username input username
     * @param password input password (plain text)
     * @return User object if successful, null otherwise
     */
    public User login(String username, String password) {
        User user = userDAO.getUserByUsername(username);

        if (user == null) {
            System.out.println("Login info: User not found.");
            return null;
        }

        if (!user.isActive()) {
            System.out.println("Login info: User is inactive.");
            return null;
        }

        if (BCrypt.checkpw(password, user.getPasswordHash())) {
            this.currentUser = user;
            return user;
        } else {
            System.out.println("Login info: Password mismatch.");
            return null;
        }
    }

    public User getCurrentUser() {
        return currentUser;
    }

    public void logout() {
        this.currentUser = null;
    }
}
