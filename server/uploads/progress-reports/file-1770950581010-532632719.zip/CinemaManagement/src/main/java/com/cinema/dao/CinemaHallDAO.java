package com.cinema.dao;

import com.cinema.model.CinemaHall;
import com.cinema.util.DatabaseConnection;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class CinemaHallDAO {

    public List<CinemaHall> getAllHalls() {
        List<CinemaHall> halls = new ArrayList<>();
        String sql = "SELECT * FROM CinemaHalls";

        try (Connection conn = DatabaseConnection.getConnection();
                PreparedStatement stmt = conn.prepareStatement(sql);
                ResultSet rs = stmt.executeQuery()) {

            while (rs.next()) {
                CinemaHall hall = new CinemaHall();
                hall.setHallId(rs.getInt("HallID"));
                hall.setName(rs.getString("Name"));
                hall.setTotalRows(rs.getInt("TotalRows"));
                hall.setTotalCols(rs.getInt("TotalCols"));
                halls.add(hall);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return halls;
    }

    // Add Hall + Generate Seats
    public boolean addCinemaHall(CinemaHall hall) {
        Connection conn = null;
        try {
            conn = DatabaseConnection.getConnection();
            conn.setAutoCommit(false);

            // 1. Insert Hall
            String sqlHall = "INSERT INTO CinemaHalls (Name, TotalRows, TotalCols) VALUES (?, ?, ?)";
            int hallId = -1;

            try (PreparedStatement stmt = conn.prepareStatement(sqlHall, Statement.RETURN_GENERATED_KEYS)) {
                stmt.setString(1, hall.getName());
                stmt.setInt(2, hall.getTotalRows());
                stmt.setInt(3, hall.getTotalCols());
                stmt.executeUpdate();

                ResultSet rs = stmt.getGeneratedKeys();
                if (rs.next()) {
                    hallId = rs.getInt(1);
                }
            }

            if (hallId == -1) {
                conn.rollback();
                return false;
            }

            // 2. Generate Seats
            String sqlSeat = "INSERT INTO Seats (HallID, RowLabel, SeatNumber, SeatType, IsActive) VALUES (?, ?, ?, ?, TRUE)";
            try (PreparedStatement stmt = conn.prepareStatement(sqlSeat)) {
                for (int r = 1; r <= hall.getTotalRows(); r++) {
                    char rowChar = (char) ('A' + r - 1); // A, B, C...
                    // Check logic: Last 2 rows are VIP? Or user inputs?
                    // MVP: All Standard for now, or last 2 rows VIP.
                    boolean isVip = (r > hall.getTotalRows() - 2) && (hall.getTotalRows() > 5);
                    String type = isVip ? "VIP" : "STANDARD";

                    for (int c = 1; c <= hall.getTotalCols(); c++) {
                        stmt.setInt(1, hallId);
                        stmt.setString(2, String.valueOf(rowChar));
                        stmt.setInt(3, c);
                        stmt.setString(4, type);
                        stmt.addBatch();
                    }
                }
                stmt.executeBatch();
            }

            conn.commit();
            return true;

        } catch (SQLException e) {
            e.printStackTrace();
            if (conn != null) {
                try {
                    conn.rollback();
                } catch (SQLException ex) {
                    ex.printStackTrace();
                }
            }
            return false;
        } finally {
            if (conn != null) {
                try {
                    conn.setAutoCommit(true);
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }
        }
    }

    // Delete Hall (and Seats)
    public boolean deleteCinemaHall(int hallId) {
        // Need to delete Seats first, then Hall.
        // IF there are Showtimes -> Error (FK Constraint). User must delete Showtimes
        // first.

        Connection conn = null;
        try {
            conn = DatabaseConnection.getConnection();
            conn.setAutoCommit(false);

            // 1. Delete Seats
            String sqlSeats = "DELETE FROM Seats WHERE HallID = ?";
            try (PreparedStatement stmt = conn.prepareStatement(sqlSeats)) {
                stmt.setInt(1, hallId);
                stmt.executeUpdate();
            }

            // 2. Delete Hall
            String sqlHall = "DELETE FROM CinemaHalls WHERE HallID = ?";
            try (PreparedStatement stmt = conn.prepareStatement(sqlHall)) {
                stmt.setInt(1, hallId);
                int rows = stmt.executeUpdate();
                if (rows == 0) {
                    conn.rollback();
                    return false;
                }
            }

            conn.commit();
            return true;

        } catch (SQLException e) {
            if (e.getErrorCode() == 1451) { // Foreign Key Constraint
                // Can throw custom exception or return false
                System.err.println("Cannot delete hall with existing showtimes.");
            } else {
                e.printStackTrace();
            }
            if (conn != null) {
                try {
                    conn.rollback();
                } catch (SQLException ex) {
                    ex.printStackTrace();
                }
            }
            return false;
        } finally {
            if (conn != null) {
                try {
                    conn.setAutoCommit(true);
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }
        }
    }
}
