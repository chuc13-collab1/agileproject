package com.cinema.util;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import org.mindrot.jbcrypt.BCrypt;

public class SchemaMigration {
    public static void main(String[] args) {
        try (Connection conn = DatabaseConnection.getConnection();
                Statement stmt = conn.createStatement()) {

            // 1. Users Table
            // SQLite: INTEGER PRIMARY KEY AUTOINCREMENT
            String createUsers = "CREATE TABLE IF NOT EXISTS Users (" +
                    "UserId INTEGER PRIMARY KEY AUTOINCREMENT, " +
                    "Username TEXT UNIQUE NOT NULL, " +
                    "PasswordHash TEXT NOT NULL, " +
                    "FullName TEXT NOT NULL, " +
                    "Role TEXT NOT NULL, " +
                    "IsActive INTEGER DEFAULT 1, " + // Boolean as 0/1
                    "CreatedAt TEXT DEFAULT CURRENT_TIMESTAMP" +
                    ")";
            stmt.executeUpdate(createUsers);

            // Default Admin
            createDefaultAdmin(conn);

            // 2. Movies Table
            String createMovies = "CREATE TABLE IF NOT EXISTS Movies (" +
                    "MovieId INTEGER PRIMARY KEY AUTOINCREMENT, " +
                    "Title TEXT NOT NULL, " +
                    "Genre TEXT, " +
                    "Duration INTEGER, " +
                    "Director TEXT, " +
                    "Description TEXT, " +
                    "ReleaseDate TEXT, " +
                    "PosterPath TEXT, " + // Added PosterPath
                    "Status TEXT DEFAULT 'SHOWING'" +
                    ")";
            stmt.executeUpdate(createMovies);

            // 3. CinemaHalls Table
            String createHalls = "CREATE TABLE IF NOT EXISTS CinemaHalls (" +
                    "HallID INTEGER PRIMARY KEY AUTOINCREMENT, " +
                    "Name TEXT NOT NULL, " +
                    "Capacity INTEGER NOT NULL" +
                    ")";
            stmt.executeUpdate(createHalls);

            // 4. Showtimes Table
            String createShowtimes = "CREATE TABLE IF NOT EXISTS Showtimes (" +
                    "ShowtimeID INTEGER PRIMARY KEY AUTOINCREMENT, " +
                    "MovieID INTEGER NOT NULL, " +
                    "HallID INTEGER NOT NULL, " +
                    "StartTime TEXT NOT NULL, " +
                    "BasePrice REAL NOT NULL, " +
                    "FOREIGN KEY (MovieID) REFERENCES Movies(MovieID), " +
                    "FOREIGN KEY (HallID) REFERENCES CinemaHalls(HallID)" +
                    ")";
            stmt.executeUpdate(createShowtimes);

            // 5. Seats Table
            String createSeats = "CREATE TABLE IF NOT EXISTS Seats (" +
                    "SeatID INTEGER PRIMARY KEY AUTOINCREMENT, " +
                    "HallID INTEGER NOT NULL, " +
                    "RowName TEXT NOT NULL, " +
                    "SeatNumber INTEGER NOT NULL, " +
                    "Type TEXT DEFAULT 'STANDARD', " +
                    "FOREIGN KEY (HallID) REFERENCES CinemaHalls(HallID)" +
                    ")";
            stmt.executeUpdate(createSeats);

            // 6. Bookings Table
            String createBookings = "CREATE TABLE IF NOT EXISTS Bookings (" +
                    "BookingID INTEGER PRIMARY KEY AUTOINCREMENT, " +
                    "UserID INTEGER, " + // Staff who sold it
                    "BookingDate TEXT DEFAULT CURRENT_TIMESTAMP, " +
                    "TotalAmount REAL NOT NULL, " +
                    "PaymentMethod TEXT, " +
                    "Status TEXT DEFAULT 'PAID', " +
                    "MemberID INTEGER, " + // Linked Member
                    "FOREIGN KEY (UserID) REFERENCES Users(UserId)" +
                    ")";
            stmt.executeUpdate(createBookings);

            // 7. Tickets Table
            String createTickets = "CREATE TABLE IF NOT EXISTS Tickets (" +
                    "TicketID INTEGER PRIMARY KEY AUTOINCREMENT, " +
                    "BookingID INTEGER NOT NULL, " +
                    "ShowtimeID INTEGER NOT NULL, " +
                    "SeatID INTEGER NOT NULL, " +
                    "Price REAL NOT NULL, " +
                    "FOREIGN KEY (BookingID) REFERENCES Bookings(BookingID), " +
                    "FOREIGN KEY (ShowtimeID) REFERENCES Showtimes(ShowtimeID), " +
                    "FOREIGN KEY (SeatID) REFERENCES Seats(SeatID)" +
                    ")";
            stmt.executeUpdate(createTickets);

            // 8. Members Table
            String createMembers = "CREATE TABLE IF NOT EXISTS Members (" +
                    "MemberID INTEGER PRIMARY KEY AUTOINCREMENT, " +
                    "FullName TEXT NOT NULL, " +
                    "DateOfBirth TEXT, " +
                    "Gender TEXT, " +
                    "PhoneNumber TEXT UNIQUE NOT NULL, " +
                    "Email TEXT, " +
                    "Address TEXT, " +
                    "MembershipLevel TEXT DEFAULT 'Standard', " +
                    "Points INTEGER DEFAULT 0, " +
                    "RegistrationDate TEXT DEFAULT CURRENT_TIMESTAMP" +
                    ")";
            stmt.executeUpdate(createMembers);

            System.out.println("SQLite Migration Success: All tables verified.");

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private static void createDefaultAdmin(Connection conn) {
        String checkSql = "SELECT COUNT(*) FROM Users WHERE Username = 'admin'";
        try (PreparedStatement checkStmt = conn.prepareStatement(checkSql);
                ResultSet rs = checkStmt.executeQuery()) {
            if (rs.next() && rs.getInt(1) == 0) {
                // Create admin
                // Note: In real app use BCrypt, here for initial setup we can use plain or
                // hashed if util available
                // For simplicity, inserting raw hash or using default helper
                // We'll insert a known hash for '123456' or just a placeholder if AuthService
                // handles hashing on login
                // Assuming AuthService uses BCrypt.checkpw, we need a valid hash.
                // $2a$10$N.zmdr9k7uOCQb376NoUnutj8iAt6ValgoL9ADM/hzpNdCz83fYWe is '123456'
                String insertSql = "INSERT INTO Users (Username, PasswordHash, FullName, Role, IsActive) VALUES (?, ?, ?, ?, 1)";
                try (PreparedStatement insertStmt = conn.prepareStatement(insertSql)) {
                    insertStmt.setString(1, "admin");
                    // Generate hash dynamically to ensure correctness
                    String hash = org.mindrot.jbcrypt.BCrypt.hashpw("123456", org.mindrot.jbcrypt.BCrypt.gensalt());
                    insertStmt.setString(2, hash);
                    insertStmt.setString(3, "Administrator");
                    insertStmt.setString(4, "ADMIN");
                    insertStmt.executeUpdate();
                    System.out.println("Default Admin created (user: admin, pass: 123456).");
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
