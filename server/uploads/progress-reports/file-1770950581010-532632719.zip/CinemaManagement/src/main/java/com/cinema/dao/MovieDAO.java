package com.cinema.dao;

import com.cinema.model.Movie;
import com.cinema.util.DatabaseConnection;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class MovieDAO {

    public List<Movie> getAllMovies() {
        List<Movie> movies = new ArrayList<>();
        String sql = "SELECT * FROM Movies";

        try (Connection conn = DatabaseConnection.getConnection();
                PreparedStatement stmt = conn.prepareStatement(sql);
                ResultSet rs = stmt.executeQuery()) {

            while (rs.next()) {
                Movie movie = new Movie();
                movie.setMovieId(rs.getInt("MovieId"));
                movie.setTitle(rs.getString("Title"));
                movie.setGenre(rs.getString("Genre"));
                movie.setDuration(rs.getInt("Duration"));
                movie.setDirector(rs.getString("Director"));
                movie.setDescription(rs.getString("Description"));
                movie.setPosterPath(rs.getString("PosterPath")); // Corrected column name

                Date releaseDate = rs.getDate("ReleaseDate");
                if (releaseDate != null) {
                    movie.setReleaseDate(releaseDate.toLocalDate());
                }

                movies.add(movie);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return movies;
    }

    public boolean addMovie(Movie movie) {
        String sql = "INSERT INTO Movies (Title, Genre, Duration, Director, Description, PosterPath, ReleaseDate) VALUES (?, ?, ?, ?, ?, ?, ?)";

        try (Connection conn = DatabaseConnection.getConnection();
                PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setString(1, movie.getTitle());
            stmt.setString(2, movie.getGenre());
            stmt.setInt(3, movie.getDuration());
            stmt.setString(4, movie.getDirector());
            stmt.setString(5, movie.getDescription());
            stmt.setString(6, movie.getPosterPath());

            if (movie.getReleaseDate() != null) {
                stmt.setDate(7, java.sql.Date.valueOf(movie.getReleaseDate()));
            } else {
                stmt.setDate(7, null);
            }

            return stmt.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    public boolean updateMovie(Movie movie) {
        String sql = "UPDATE Movies SET Title=?, Genre=?, Duration=?, Director=?, Description=?, PosterPath=?, ReleaseDate=? WHERE MovieId=?";

        try (Connection conn = DatabaseConnection.getConnection();
                PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setString(1, movie.getTitle());
            stmt.setString(2, movie.getGenre());
            stmt.setInt(3, movie.getDuration());
            stmt.setString(4, movie.getDirector());
            stmt.setString(5, movie.getDescription());
            stmt.setString(6, movie.getPosterPath());
            if (movie.getReleaseDate() != null) {
                stmt.setDate(7, java.sql.Date.valueOf(movie.getReleaseDate()));
            } else {
                stmt.setDate(7, null);
            }
            stmt.setInt(8, movie.getMovieId());

            return stmt.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    public boolean deleteMovie(int movieId) {
        String sql = "DELETE FROM Movies WHERE MovieId=?";

        try (Connection conn = DatabaseConnection.getConnection();
                PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setInt(1, movieId);
            return stmt.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }
}
