package com.cinema.dao;

import com.cinema.model.Seat;
import com.cinema.util.DatabaseConnection;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class SeatDAO {

    // Get all seats for a hall
    public List<Seat> getSeatsByHallId(int hallId) {
        List<Seat> seats = new ArrayList<>();
        String sql = "SELECT * FROM Seats WHERE HallID = ? ORDER BY RowLabel, SeatNumber";

        try (Connection conn = DatabaseConnection.getConnection();
                PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setInt(1, hallId);
            ResultSet rs = stmt.executeQuery();

            while (rs.next()) {
                Seat s = new Seat();
                s.setSeatId(rs.getInt("SeatID"));
                s.setHallId(rs.getInt("HallID"));
                s.setRowLabel(rs.getString("RowLabel"));
                s.setSeatNumber(rs.getInt("SeatNumber"));
                s.setSeatType(rs.getString("SeatType"));
                s.setActive(rs.getBoolean("IsActive"));
                seats.add(s);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return seats;
    }

    // Get booked seat IDs for a specific showtime
    public List<Integer> getBookedSeatIds(int showtimeId) {
        List<Integer> bookedIds = new ArrayList<>();
        String sql = "SELECT SeatID FROM Tickets WHERE ShowtimeID = ? AND Status = 'ACTIVE'";

        try (Connection conn = DatabaseConnection.getConnection();
                PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setInt(1, showtimeId);
            ResultSet rs = stmt.executeQuery();

            while (rs.next()) {
                bookedIds.add(rs.getInt("SeatID"));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return bookedIds;
    }
}
