package com.cinema.ui.content;

import com.cinema.dao.MovieDAO;
import com.cinema.model.Movie;
import com.cinema.ui.MainFrame;
import com.formdev.flatlaf.FlatClientProperties;

import javax.swing.*;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.io.File;
import java.time.LocalDate;
import java.util.List;
import javax.imageio.ImageIO;

public class MovieManagementPanel extends JPanel {

    private JTable movieTable;
    private DefaultTableModel tableModel;
    private MovieDAO movieDAO;
    private MainFrame mainFrame;

    public MovieManagementPanel(MainFrame mainFrame) {
        this.mainFrame = mainFrame;
        this.movieDAO = new MovieDAO();
        initComponents();
        loadMovies();
    }

    // Default constructor for compatibility if needed (though we updated MainFrame)
    public MovieManagementPanel() {
        this(null);
    }

    private void initComponents() {
        setLayout(new BorderLayout());
        setBackground(new Color(40, 42, 54));

        // Toolbar
        JPanel toolbar = new JPanel(new FlowLayout(FlowLayout.LEFT));
        toolbar.setOpaque(false);

        JButton btnAdd = createButton("Thêm Phim", new Color(80, 250, 123)); // Green
        JButton btnEdit = createButton("Sửa", new Color(255, 184, 108)); // Orange
        JButton btnDelete = createButton("Xóa", new Color(255, 85, 85)); // Red
        JButton btnRefresh = createButton("Làm mới", new Color(98, 114, 164)); // Purple

        btnAdd.addActionListener(e -> showMovieForm(null));
        btnEdit.addActionListener(e -> editSelectedMovie());
        btnDelete.addActionListener(e -> deleteSelectedMovie());
        btnRefresh.addActionListener(e -> {
            loadMovies();
            if (mainFrame != null)
                mainFrame.resetRightSidebar();
        });

        toolbar.add(btnAdd);
        toolbar.add(btnEdit);
        toolbar.add(btnDelete);
        toolbar.add(btnRefresh);

        add(toolbar, BorderLayout.NORTH);

        // Table
        String[] columns = { "ID", "Poster", "Tên Phim", "Thể Loại", "Thời Lượng", "Đạo Diễn", "Ngày Chiếu" };
        tableModel = new DefaultTableModel(columns, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }

            @Override
            public Class<?> getColumnClass(int columnIndex) {
                if (columnIndex == 1)
                    return ImageIcon.class;
                return Object.class;
            }
        };

        movieTable = new JTable(tableModel);
        movieTable.setRowHeight(120);
        movieTable.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        movieTable.getTableHeader().setFont(new Font("SansSerif", Font.BOLD, 14));

        movieTable.getColumnModel().getColumn(1).setCellRenderer(new ImageRenderer());

        movieTable.getColumnModel().getColumn(0).setMaxWidth(50);
        movieTable.getColumnModel().getColumn(1).setMinWidth(90);
        movieTable.getColumnModel().getColumn(1).setMaxWidth(90);

        // Add Selection Listener
        movieTable.getSelectionModel().addListSelectionListener(e -> {
            if (!e.getValueIsAdjusting() && movieTable.getSelectedRow() != -1) {
                updateSidebarWithSelection();
            }
        });

        // Also listen for mouse clicks to ensure update
        movieTable.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                updateSidebarWithSelection();
            }
        });

        JScrollPane scrollPane = new JScrollPane(movieTable);
        scrollPane.setBorder(BorderFactory.createEmptyBorder());
        scrollPane.getViewport().setBackground(new Color(40, 42, 54));

        add(scrollPane, BorderLayout.CENTER);
    }

    private void updateSidebarWithSelection() {
        if (mainFrame == null)
            return;

        int row = movieTable.getSelectedRow();
        if (row != -1) {
            // Get data from table
            int id = (int) tableModel.getValueAt(row, 0);
            String title = (String) tableModel.getValueAt(row, 2);
            String genre = (String) tableModel.getValueAt(row, 3);
            String duration = String.valueOf(tableModel.getValueAt(row, 4)); // Safe conversion
            String director = (String) tableModel.getValueAt(row, 5);

            // Get Image Icon
            ImageIcon icon = null;
            Object iconObj = tableModel.getValueAt(row, 1);
            if (iconObj instanceof ImageIcon) {
                // Scale larger for sidebar
                Image img = ((ImageIcon) iconObj).getImage();
                icon = new ImageIcon(img.getScaledInstance(200, 280, Image.SCALE_SMOOTH));
            }

            // Re-fetch description if possible, or just use what we have
            // Since description is not in table, we need to fetch from DB for best
            // experience
            // Simply fetching all movies again is inefficient but simplest for now without
            // changing DAO
            List<Movie> allMovies = movieDAO.getAllMovies();
            Movie m = allMovies.stream().filter(mov -> mov.getMovieId() == id).findFirst().orElse(null);

            mainFrame.setRightSidebarContent(createDetailPanel(m, icon));
        }
    }

    private JPanel createDetailPanel(Movie m, ImageIcon icon) {
        JPanel panel = new JPanel();
        panel.setLayout(new BoxLayout(panel, BoxLayout.Y_AXIS));
        panel.setOpaque(false);

        // Poster (Centered)
        if (m != null && m.getPosterPath() != null) {
            // Use high-res if available
            try {
                Image image = null;
                if (m.getPosterPath().startsWith("http")) {
                    image = ImageIO.read(new java.net.URL(m.getPosterPath()));
                } else {
                    File imgFile = new File(m.getPosterPath());
                    if (imgFile.exists()) {
                        image = ImageIO.read(imgFile);
                    }
                }

                if (image != null) {
                    Image scaled = image.getScaledInstance(200, 300, Image.SCALE_SMOOTH);
                    icon = new ImageIcon(scaled);
                }
            } catch (Exception ex) {
            }
        }

        JLabel posterLabel = new JLabel();
        if (icon != null) {
            posterLabel.setIcon(icon);
        } else {
            posterLabel.setText("No Poster");
            posterLabel.setForeground(Color.GRAY);
        }
        posterLabel.setAlignmentX(Component.CENTER_ALIGNMENT);
        panel.add(posterLabel);

        panel.add(Box.createVerticalStrut(20));

        // Title
        JLabel titleLabel = new JLabel(m != null ? m.getTitle() : "Unknown");
        titleLabel.setFont(new Font("SansSerif", Font.BOLD, 22));
        titleLabel.setForeground(Color.WHITE);
        titleLabel.setAlignmentX(Component.CENTER_ALIGNMENT);
        panel.add(titleLabel);

        // Genre & Info
        panel.add(Box.createVerticalStrut(10));
        JLabel genreLabel = new JLabel(m != null ? m.getGenre() : "");
        genreLabel.setForeground(new Color(179, 179, 179));
        genreLabel.setAlignmentX(Component.CENTER_ALIGNMENT);
        panel.add(genreLabel);

        JLabel durationLabel = new JLabel(m != null ? m.getDuration() + " phút" : "");
        durationLabel.setForeground(new Color(179, 179, 179));
        durationLabel.setAlignmentX(Component.CENTER_ALIGNMENT);
        panel.add(durationLabel);

        panel.add(Box.createVerticalStrut(20));

        // Description
        JTextArea desc = new JTextArea(m != null ? m.getDescription() : "");
        desc.setLineWrap(true);
        desc.setWrapStyleWord(true);
        desc.setOpaque(false);
        desc.setForeground(new Color(200, 200, 200));
        desc.setFont(new Font("SansSerif", Font.ITALIC, 14));
        desc.setEditable(false);
        desc.setAlignmentX(Component.CENTER_ALIGNMENT);

        panel.add(desc);

        return panel;
    }

    private JButton createButton(String text, Color bg) {
        JButton btn = new JButton(text);
        btn.setFont(new Font("SansSerif", Font.BOLD, 14));
        btn.setBackground(bg);
        btn.setForeground(new Color(40, 42, 54));
        btn.setFocusPainted(false);
        btn.putClientProperty(FlatClientProperties.STYLE, "arc: 10");
        return btn;
    }

    private void loadMovies() {
        tableModel.setRowCount(0);
        List<Movie> movies = movieDAO.getAllMovies();
        for (Movie m : movies) {
            // Load and scale image
            ImageIcon icon = null;
            if (m.getPosterPath() != null && !m.getPosterPath().isEmpty()) {
                try {
                    Image image = null;
                    if (m.getPosterPath().startsWith("http")) {
                        image = ImageIO.read(new java.net.URL(m.getPosterPath()));
                    } else {
                        File imgFile = new File(m.getPosterPath());
                        if (imgFile.exists()) {
                            image = ImageIO.read(imgFile);
                        }
                    }

                    if (image != null) {
                        Image scaled = image.getScaledInstance(80, 110, Image.SCALE_SMOOTH);
                        icon = new ImageIcon(scaled);
                    }
                } catch (Exception e) {
                    // System.err.println("Could not load image: " + m.getPosterPath());
                }
            }

            tableModel.addRow(new Object[] {
                    m.getMovieId(),
                    icon, // Pass ImageIcon here
                    m.getTitle(),
                    m.getGenre(),
                    m.getDuration(), // removed "phút" to verify data access
                    m.getDirector(),
                    m.getReleaseDate()
            });
        }
    }

    // Custom Renderer
    private static class ImageRenderer extends DefaultTableCellRenderer {
        @Override
        public Component getTableCellRendererComponent(JTable table, Object value, boolean isSelected, boolean hasFocus,
                int row, int column) {
            JLabel label = new JLabel();
            if (value instanceof ImageIcon) {
                label.setIcon((ImageIcon) value);
            } else {
                label.setText("No Image");
            }
            label.setHorizontalAlignment(SwingConstants.CENTER);
            if (isSelected) {
                label.setBackground(table.getSelectionBackground());
                label.setOpaque(true);
            } else {
                label.setBackground(table.getBackground());
                label.setOpaque(true); // Should match table bg
            }
            return label;
        }
    }

    private void showMovieForm(Movie movie) {
        JDialog dialog = new JDialog((Frame) SwingUtilities.getWindowAncestor(this),
                movie == null ? "Thêm Phim Mới" : "Sửa Phim", true);
        dialog.setLayout(new GridBagLayout());
        dialog.setSize(400, 650);
        dialog.setLocationRelativeTo(this);

        JTextField txtTitle = new JTextField(20);
        JTextField txtGenre = new JTextField(20);
        JTextField txtDuration = new JTextField(20);
        JTextField txtDirector = new JTextField(20);
        JTextField txtPoster = new JTextField(20);
        JTextField txtDate = new JTextField(20);
        JTextArea txtDesc = new JTextArea(3, 20);

        txtDate.setText(LocalDate.now().toString());

        if (movie != null) {
            txtTitle.setText(movie.getTitle());
            txtGenre.setText(movie.getGenre());
            txtDuration.setText(String.valueOf(movie.getDuration()));
            txtDirector.setText(movie.getDirector());
            txtPoster.setText(movie.getPosterPath());
            txtDesc.setText(movie.getDescription());
            if (movie.getReleaseDate() != null) {
                txtDate.setText(movie.getReleaseDate().toString());
            }
        }

        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(5, 5, 5, 5);
        gbc.fill = GridBagConstraints.HORIZONTAL;

        addFormField(dialog, "Tên Phim:", txtTitle, gbc, 0);
        addFormField(dialog, "Thể Loại:", txtGenre, gbc, 1);
        addFormField(dialog, "Thời Lượng:", txtDuration, gbc, 2);
        addFormField(dialog, "Đạo Diễn:", txtDirector, gbc, 3);
        addFormField(dialog, "Poster URL:", txtPoster, gbc, 4);
        addFormField(dialog, "Ngày chiếu:", txtDate, gbc, 5);

        gbc.gridx = 0;
        gbc.gridy = 6;
        dialog.add(new JLabel("Mô Tả:"), gbc);
        gbc.gridx = 1;
        dialog.add(new JScrollPane(txtDesc), gbc);

        JButton btnSave = new JButton("Lưu");
        btnSave.addActionListener(e -> {
            try {
                Movie m = movie != null ? movie : new Movie();
                m.setTitle(txtTitle.getText());
                m.setGenre(txtGenre.getText());
                m.setDuration(Integer.parseInt(txtDuration.getText()));
                m.setDirector(txtDirector.getText());
                m.setPosterPath(txtPoster.getText());
                m.setDescription(txtDesc.getText());
                m.setReleaseDate(LocalDate.parse(txtDate.getText()));

                boolean success;
                if (movie == null) {
                    success = movieDAO.addMovie(m);
                } else {
                    success = movieDAO.updateMovie(m);
                }

                if (success) {
                    JOptionPane.showMessageDialog(dialog, "Lưu thành công!");
                    dialog.dispose();
                    loadMovies();
                } else {
                    JOptionPane.showMessageDialog(dialog, "Lỗi khi lưu phim!", "Lỗi", JOptionPane.ERROR_MESSAGE);
                }
            } catch (Exception ex) {
                JOptionPane.showMessageDialog(dialog, "Dữ liệu không hợp lệ: " + ex.getMessage());
            }
        });

        gbc.gridx = 1;
        gbc.gridy = 7;
        dialog.add(btnSave, gbc);

        dialog.setVisible(true);
    }

    private void addFormField(JDialog dialog, String label, JComponent field, GridBagConstraints gbc, int y) {
        gbc.gridx = 0;
        gbc.gridy = y;
        dialog.add(new JLabel(label), gbc);
        gbc.gridx = 1;
        dialog.add(field, gbc);
    }

    private void editSelectedMovie() {
        int row = movieTable.getSelectedRow();
        if (row == -1) {
            JOptionPane.showMessageDialog(this, "Vui lòng chọn phim để sửa.");
            return;
        }
        int id = (int) tableModel.getValueAt(row, 0);

        List<Movie> allMovies = movieDAO.getAllMovies();
        Movie selectedMovie = allMovies.stream().filter(m -> m.getMovieId() == id).findFirst().orElse(null);

        if (selectedMovie != null) {
            showMovieForm(selectedMovie);
        }
    }

    private void deleteSelectedMovie() {
        int row = movieTable.getSelectedRow();
        if (row == -1) {
            JOptionPane.showMessageDialog(this, "Vui lòng chọn phim để xóa.");
            return;
        }
        int confirm = JOptionPane.showConfirmDialog(this, "Bạn có chắc chắn muốn xóa phim này?", "Xác nhận",
                JOptionPane.YES_NO_OPTION);
        if (confirm == JOptionPane.YES_OPTION) {
            int id = (int) tableModel.getValueAt(row, 0);
            if (movieDAO.deleteMovie(id)) {
                loadMovies();
            } else {
                JOptionPane.showMessageDialog(this, "Xóa thất bại!");
            }
        }
    }
}
