package com.cinema.dao;

import com.cinema.util.DatabaseConnection;
import java.math.BigDecimal;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

public class DashboardDAO {

    public BigDecimal getTodayRevenue() {
        String sql = "SELECT SUM(TotalAmount) FROM Bookings WHERE DATE(BookingDate) = CURRENT_DATE AND Status = 'PAID'";
        try (Connection conn = DatabaseConnection.getConnection();
                PreparedStatement stmt = conn.prepareStatement(sql);
                ResultSet rs = stmt.executeQuery()) {
            if (rs.next()) {
                BigDecimal total = rs.getBigDecimal(1);
                return total != null ? total : BigDecimal.ZERO;
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return BigDecimal.ZERO;
    }

    public int getTodayTicketsSold() {
        // Count tickets linked to PAID bookings made today
        String sql = "SELECT COUNT(t.TicketID) " +
                "FROM Tickets t " +
                "JOIN Bookings b ON t.BookingID = b.BookingID " +
                "WHERE DATE(b.BookingDate) = CURRENT_DATE AND b.Status = 'PAID'";
        try (Connection conn = DatabaseConnection.getConnection();
                PreparedStatement stmt = conn.prepareStatement(sql);
                ResultSet rs = stmt.executeQuery()) {
            if (rs.next()) {
                return rs.getInt(1);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return 0;
    }

    public List<com.cinema.model.Movie> getMoviesShowingToday() {
        List<com.cinema.model.Movie> movies = new ArrayList<>();
        // Movies that have showtimes today
        String sql = "SELECT DISTINCT m.MovieID, m.Title, m.Genre, m.Duration, m.PosterPath " +
                "FROM Movies m " +
                "JOIN Showtimes s ON m.MovieID = s.MovieID " +
                "WHERE DATE(s.StartTime) = CURRENT_DATE";
        try (Connection conn = DatabaseConnection.getConnection();
                PreparedStatement stmt = conn.prepareStatement(sql);
                ResultSet rs = stmt.executeQuery()) {
            while (rs.next()) {
                com.cinema.model.Movie m = new com.cinema.model.Movie();
                m.setMovieId(rs.getInt("MovieID"));
                m.setTitle(rs.getString("Title"));
                m.setGenre(rs.getString("Genre"));
                m.setDuration(rs.getInt("Duration"));
                m.setPosterPath(rs.getString("PosterPath"));
                movies.add(m);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return movies;
    }
}
