package com.cinema.ui.content;

import com.cinema.dao.ReportDAO;
import com.formdev.flatlaf.FlatClientProperties;

import javax.swing.*;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import java.util.List;

public class ReportPanel extends JPanel {

    private ReportDAO reportDAO;

    // Components
    private JTextField txtFromDate;
    private JTextField txtToDate;

    private JTable tblDaily;
    private DefaultTableModel modelDaily;

    private JTable tblMovie;
    private DefaultTableModel modelMovie;

    private JLabel lblTotalRevenue;
    private JLabel lblTotalTickets;

    public ReportPanel() {
        this.reportDAO = new ReportDAO();
        initComponents();
        loadData();
    }

    private void initComponents() {
        setLayout(new BorderLayout(10, 10));
        setBackground(new Color(40, 42, 54));
        setBorder(BorderFactory.createEmptyBorder(15, 15, 15, 15));

        // --- Header & Filter ---
        JPanel topPanel = new JPanel(new BorderLayout());
        topPanel.setOpaque(false);

        JLabel title = new JLabel("Báo Cáo Thống Kê");
        title.setFont(new Font("SansSerif", Font.BOLD, 24));
        title.setForeground(Color.WHITE);
        topPanel.add(title, BorderLayout.WEST);

        JPanel filterPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        filterPanel.setOpaque(false);

        txtFromDate = new JTextField(10);
        txtFromDate.putClientProperty(FlatClientProperties.PLACEHOLDER_TEXT, "yyyy-MM-dd");
        txtFromDate.setToolTipText("Từ ngày");

        txtToDate = new JTextField(10);
        txtToDate.putClientProperty(FlatClientProperties.PLACEHOLDER_TEXT, "yyyy-MM-dd");
        txtToDate.setToolTipText("Đến ngày");

        JButton btnFilter = new JButton("Lọc");
        btnFilter.setBackground(new Color(80, 150, 255));
        btnFilter.setForeground(Color.WHITE);
        btnFilter.addActionListener(e -> loadData());

        JButton btnClear = new JButton("Xóa Lọc");
        btnClear.addActionListener(e -> {
            txtFromDate.setText("");
            txtToDate.setText("");
            loadData();
        });

        filterPanel.add(new JLabel("Từ:"));
        filterPanel.add(txtFromDate);
        filterPanel.add(new JLabel("Đến:"));
        filterPanel.add(txtToDate);
        filterPanel.add(Box.createHorizontalStrut(10));
        filterPanel.add(btnFilter);
        filterPanel.add(btnClear);

        topPanel.add(filterPanel, BorderLayout.EAST);
        add(topPanel, BorderLayout.NORTH);

        // --- Center: Split Pane (Movie vs Daily) ---
        JSplitPane splitPane = new JSplitPane(JSplitPane.HORIZONTAL_SPLIT);
        splitPane.setResizeWeight(0.5);
        splitPane.setDividerLocation(0.5);
        splitPane.setOpaque(false);
        splitPane.setBorder(null);

        // Left: Movie Stats
        JPanel pnlMovie = new JPanel(new BorderLayout());
        pnlMovie.setOpaque(false);
        pnlMovie.setBorder(BorderFactory.createTitledBorder(null, "Doanh Thu Theo Phim", 0, 0,
                new Font("SansSerif", Font.BOLD, 14), Color.ORANGE));

        String[] colMovie = { "Tên Phim", "Vé Bán", "Doanh Thu" };
        modelMovie = new DefaultTableModel(colMovie, 0) {
            public boolean isCellEditable(int r, int c) {
                return false;
            }
        };
        tblMovie = new JTable(modelMovie);
        setupTable(tblMovie);
        pnlMovie.add(new JScrollPane(tblMovie), BorderLayout.CENTER);

        // Right: Daily Stats
        JPanel pnlDaily = new JPanel(new BorderLayout());
        pnlDaily.setOpaque(false);
        pnlDaily.setBorder(BorderFactory.createTitledBorder(null, "Chi Tiết Theo Ngày", 0, 0,
                new Font("SansSerif", Font.BOLD, 14), Color.GREEN));

        String[] colDaily = { "Ngày", "Số Đơn", "Doanh Thu" };
        modelDaily = new DefaultTableModel(colDaily, 0) {
            public boolean isCellEditable(int r, int c) {
                return false;
            }
        };
        tblDaily = new JTable(modelDaily);
        setupTable(tblDaily);
        pnlDaily.add(new JScrollPane(tblDaily), BorderLayout.CENTER);

        splitPane.setLeftComponent(pnlMovie);
        splitPane.setRightComponent(pnlDaily);

        add(splitPane, BorderLayout.CENTER);

        // --- Bottom: Summary ---
        JPanel botPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT, 30, 10));
        botPanel.setOpaque(false);

        lblTotalTickets = new JLabel("Tổng Vé: 0");
        lblTotalTickets.setFont(new Font("SansSerif", Font.BOLD, 16));
        lblTotalTickets.setForeground(Color.LIGHT_GRAY);

        lblTotalRevenue = new JLabel("Tổng Doanh Thu: 0 VNĐ");
        lblTotalRevenue.setFont(new Font("SansSerif", Font.BOLD, 20));
        lblTotalRevenue.setForeground(new Color(80, 250, 123));

        botPanel.add(lblTotalTickets);
        botPanel.add(lblTotalRevenue);
        add(botPanel, BorderLayout.SOUTH);
    }

    private void setupTable(JTable t) {
        t.setRowHeight(30);
        t.getTableHeader().setFont(new Font("SansSerif", Font.BOLD, 13));
        t.setFillsViewportHeight(true);
        // Right align numbers
        DefaultTableCellRenderer right = new DefaultTableCellRenderer();
        right.setHorizontalAlignment(SwingConstants.RIGHT);
        t.getColumnModel().getColumn(t.getColumnCount() - 1).setCellRenderer(right); // Revenue
        if (t.getColumnCount() > 2)
            t.getColumnModel().getColumn(1).setCellRenderer(right); // Count
    }

    private void loadData() {
        LocalDate from = parseDate(txtFromDate.getText());
        LocalDate to = parseDate(txtToDate.getText());

        // 1. Movie Data
        modelMovie.setRowCount(0);
        List<ReportDAO.MovieRevenue> movies = reportDAO.getRevenueByMovie(from, to);
        BigDecimal grandTotal = BigDecimal.ZERO;
        int totalTickets = 0;

        for (ReportDAO.MovieRevenue m : movies) {
            modelMovie.addRow(new Object[] {
                    m.getMovieTitle(),
                    m.getTicketsSold(),
                    String.format("%,.0f", m.getTotalRevenue())
            });
            grandTotal = grandTotal.add(m.getTotalRevenue());
            totalTickets += m.getTicketsSold();
        }

        // 2. Daily Data
        modelDaily.setRowCount(0);
        List<ReportDAO.DailyRevenue> days = reportDAO.getDailyRevenue(from, to);
        DateTimeFormatter dtf = DateTimeFormatter.ofPattern("dd/MM/yyyy");

        for (ReportDAO.DailyRevenue d : days) {
            modelDaily.addRow(new Object[] {
                    d.getDate().format(dtf),
                    d.getBookingCount(),
                    String.format("%,.0f", d.getTotalRevenue())
            });
        }

        // 3. Update Totals
        lblTotalRevenue.setText("Tổng Doanh Thu: " + String.format("%,.0f VNĐ", grandTotal));
        lblTotalTickets.setText("Tổng Vé: " + totalTickets);
    }

    private LocalDate parseDate(String s) {
        if (s == null || s.trim().isEmpty())
            return null;
        try {
            return LocalDate.parse(s.trim());
        } catch (DateTimeParseException e) {
            return null; // Ignore invalid
        }
    }
}
