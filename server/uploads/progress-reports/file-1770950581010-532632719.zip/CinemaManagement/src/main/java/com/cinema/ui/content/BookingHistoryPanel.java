package com.cinema.ui.content;

import com.cinema.dao.TicketDAO;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.time.format.DateTimeFormatter;
import java.util.List;

public class BookingHistoryPanel extends JPanel {

    private JTable table;
    private DefaultTableModel tableModel;
    private TicketDAO ticketDAO;

    public BookingHistoryPanel() {
        ticketDAO = new TicketDAO();
        initComponents();
        loadBookings();
    }

    private void initComponents() {
        setLayout(new BorderLayout(20, 20));
        setBackground(new Color(40, 42, 54));
        setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));

        // Header
        JLabel title = new JLabel("Lịch Sử Bán Vé & Hoàn Vé");
        title.setFont(new Font("SansSerif", Font.BOLD, 24));
        title.setForeground(Color.WHITE);
        add(title, BorderLayout.NORTH);

        // Center Table
        String[] cols = { "Mã HĐ", "Phim", "Ngày giờ", "Nhân Viên", "Tổng Tiền", "Trạng Thái" };
        tableModel = new DefaultTableModel(cols, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };

        table = new JTable(tableModel);
        table.setRowHeight(35);
        table.getTableHeader().setFont(new Font("SansSerif", Font.BOLD, 14));

        // Custom Renderer for Status color
        table.setDefaultRenderer(Object.class, new javax.swing.table.DefaultTableCellRenderer() {
            @Override
            public Component getTableCellRendererComponent(JTable table, Object value, boolean isSelected,
                    boolean hasFocus, int row, int column) {
                Component c = super.getTableCellRendererComponent(table, value, isSelected, hasFocus, row, column);
                if (column == 5) { // Status column index changed to 5
                    String status = (String) value;
                    if ("PAID".equals(status)) {
                        c.setForeground(new Color(80, 250, 123)); // Green
                    } else if ("REFUNDED".equals(status)) {
                        c.setForeground(new Color(255, 85, 85)); // Red
                    } else {
                        c.setForeground(Color.BLACK);
                    }
                    if (isSelected)
                        c.setForeground(Color.WHITE);
                } else {
                    if (!isSelected)
                        c.setForeground(Color.BLACK);
                }
                return c;
            }
        });

        JScrollPane scroll = new JScrollPane(table);
        scroll.getViewport().setBackground(new Color(40, 42, 54));
        add(scroll, BorderLayout.CENTER);

        // Buttons
        JPanel btnPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        btnPanel.setOpaque(false);

        JButton btnRefresh = new JButton("Làm mới");
        btnRefresh.addActionListener(e -> loadBookings());
        btnPanel.add(btnRefresh);

        btnPanel.add(Box.createHorizontalStrut(10));

        JButton btnRefund = new JButton("Hoàn Vé (Refund)");
        btnRefund.setBackground(new Color(255, 85, 85));
        btnRefund.setForeground(Color.WHITE);
        btnRefund.addActionListener(e -> refundSelected());
        btnPanel.add(btnRefund);

        add(btnPanel, BorderLayout.SOUTH);
    }

    private void loadBookings() {
        tableModel.setRowCount(0);
        List<TicketDAO.BookingRecord> list = ticketDAO.getAllBookings();
        DateTimeFormatter dtf = DateTimeFormatter.ofPattern("HH:mm dd/MM/yyyy");

        for (TicketDAO.BookingRecord r : list) {
            tableModel.addRow(new Object[] {
                    r.getId(),
                    r.getMovieTitle(),
                    r.getBookingDate() != null ? r.getBookingDate().format(dtf) : "N/A",
                    r.getStaffName(),
                    String.format("%,.0f VNĐ", r.getTotalAmount()),
                    r.getStatus()
            });
        }
    }

    private void refundSelected() {
        int row = table.getSelectedRow();
        if (row == -1) {
            JOptionPane.showMessageDialog(this, "Vui lòng chọn hóa đơn để hoàn tiền!");
            return;
        }

        String status = (String) tableModel.getValueAt(row, 5); // Status index 5
        if ("REFUNDED".equals(status)) {
            JOptionPane.showMessageDialog(this, "Hóa đơn này đã được hoàn tiền rồi!");
            return;
        }

        int id = (int) tableModel.getValueAt(row, 0);
        int confirm = JOptionPane.showConfirmDialog(this,
                "Bạn có chắc chắn muốn hoàn tiền cho hóa đơn #" + id + "?\nThao tác này không thể hoàn tác.",
                "Xác nhận hoàn tiền", JOptionPane.YES_NO_OPTION);

        if (confirm == JOptionPane.YES_OPTION) {
            if (ticketDAO.refundBooking(id)) {
                JOptionPane.showMessageDialog(this, "Đã hoàn vé thành công!");
                loadBookings();
            } else {
                JOptionPane.showMessageDialog(this, "Có lỗi xảy ra khi hoàn vé.");
            }
        }
    }
}
