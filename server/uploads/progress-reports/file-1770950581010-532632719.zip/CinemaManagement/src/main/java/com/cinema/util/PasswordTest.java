package com.cinema.util;

import org.mindrot.jbcrypt.BCrypt;
import java.sql.Connection;
import java.sql.PreparedStatement;

public class PasswordTest {
    public static void main(String[] args) {
        String password = "admin123";
        String hash = BCrypt.hashpw(password, BCrypt.gensalt());
        System.out.println("Generated Hash: " + hash);

        try (Connection conn = DatabaseConnection.getConnection()) {
            if (conn == null) {
                System.out.println("Connection failed!");
                return;
            }

            String sql = "UPDATE Users SET PasswordHash = ? WHERE Username IN ('admin', 'staff01', 'staff02')";
            try (PreparedStatement stmt = conn.prepareStatement(sql)) {
                stmt.setString(1, hash);
                int rows = stmt.executeUpdate();
                System.out.println("Successfully reset passwords for " + rows + " users to 'admin123'.");
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
