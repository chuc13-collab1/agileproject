package com.cinema.util;

import com.cinema.dao.CinemaHallDAO;
import com.cinema.dao.SeatDAO;
import com.cinema.model.CinemaHall;
import com.cinema.model.Seat;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.List;

public class FixSeatData {
    public static void main(String[] args) {
        System.out.println("Checking for missing seat data...");

        CinemaHallDAO hallDAO = new CinemaHallDAO();
        SeatDAO seatDAO = new SeatDAO();

        List<CinemaHall> halls = hallDAO.getAllHalls();

        for (CinemaHall hall : halls) {
            List<Seat> seats = seatDAO.getSeatsByHallId(hall.getHallId());
            if (seats.isEmpty()) {
                System.out.println("Generating seats for: " + hall.getName() + " (" + hall.getTotalRows() + "x"
                        + hall.getTotalCols() + ")");
                generateSeats(hall);
            } else {
                System.out.println("Seats already exist for: " + hall.getName());
            }
        }
        System.out.println("Done.");
    }

    private static void generateSeats(CinemaHall hall) {
        String sqlSeat = "INSERT INTO Seats (HallID, RowLabel, SeatNumber, SeatType, IsActive) VALUES (?, ?, ?, ?, TRUE)";

        try (Connection conn = DatabaseConnection.getConnection();
                PreparedStatement stmt = conn.prepareStatement(sqlSeat)) {

            conn.setAutoCommit(false);

            for (int r = 1; r <= hall.getTotalRows(); r++) {
                char rowChar = (char) ('A' + r - 1);
                boolean isVip = (r > hall.getTotalRows() - 2) && (hall.getTotalRows() > 5);
                String type = isVip ? "VIP" : "STANDARD";

                for (int c = 1; c <= hall.getTotalCols(); c++) {
                    stmt.setInt(1, hall.getHallId());
                    stmt.setString(2, String.valueOf(rowChar));
                    stmt.setInt(3, c);
                    stmt.setString(4, type);
                    stmt.addBatch();
                }
            }
            stmt.executeBatch();
            conn.commit();
            conn.setAutoCommit(true);
            System.out.println(" -> Successfully created " + (hall.getTotalRows() * hall.getTotalCols()) + " seats.");

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}
