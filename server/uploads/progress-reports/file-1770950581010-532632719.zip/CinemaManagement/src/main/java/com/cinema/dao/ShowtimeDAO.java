package com.cinema.dao;

import com.cinema.model.Showtime;
import com.cinema.util.DatabaseConnection;

import java.math.BigDecimal;
import java.sql.*;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

public class ShowtimeDAO {

    public List<Showtime> getAllShowtimes() {
        List<Showtime> showtimes = new ArrayList<>();
        // Join with Movies and Halls to get names
        String sql = "SELECT DISTINCT s.*, m.Title, h.Name as HallName FROM Showtimes s " +
                "JOIN Movies m ON s.MovieID = m.MovieID " +
                "JOIN CinemaHalls h ON s.HallID = h.HallID " +
                "ORDER BY s.StartTime DESC";

        try (Connection conn = DatabaseConnection.getConnection();
                PreparedStatement stmt = conn.prepareStatement(sql);
                ResultSet rs = stmt.executeQuery()) {

            while (rs.next()) {
                Showtime s = new Showtime();
                s.setShowtimeId(rs.getInt("ShowtimeID"));
                s.setMovieId(rs.getInt("MovieID"));
                s.setHallId(rs.getInt("HallID"));
                s.setStartTime(rs.getTimestamp("StartTime").toLocalDateTime());
                s.setEndTime(rs.getTimestamp("EndTime").toLocalDateTime());
                s.setBasePrice(rs.getBigDecimal("BasePrice"));

                s.setMovieTitle(rs.getString("Title"));
                s.setHallName(rs.getString("HallName"));

                showtimes.add(s);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return showtimes;
    }

    public boolean addShowtime(Showtime s) {
        String sql = "INSERT INTO Showtimes (MovieID, HallID, StartTime, EndTime, BasePrice) VALUES (?, ?, ?, ?, ?)";

        try (Connection conn = DatabaseConnection.getConnection();
                PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setInt(1, s.getMovieId());
            stmt.setInt(2, s.getHallId());
            stmt.setTimestamp(3, Timestamp.valueOf(s.getStartTime()));
            stmt.setTimestamp(4, Timestamp.valueOf(s.getEndTime()));
            stmt.setBigDecimal(5, s.getBasePrice());

            return stmt.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    public boolean deleteShowtime(int id) {
        String sql = "DELETE FROM Showtimes WHERE ShowtimeID=?";
        try (Connection conn = DatabaseConnection.getConnection();
                PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, id);
            return stmt.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    // Check for overlap
    public boolean checkOverlap(int hallId, LocalDateTime start, LocalDateTime end) {
        String sql = "SELECT COUNT(*) FROM Showtimes WHERE HallID = ? AND " +
                "((StartTime <= ? AND EndTime >= ?) OR " + // New start is inside existing
                "(StartTime <= ? AND EndTime >= ?) OR " + // New end is inside existing
                "(StartTime >= ? AND EndTime <= ?))"; // New covers existing fully

        try (Connection conn = DatabaseConnection.getConnection();
                PreparedStatement stmt = conn.prepareStatement(sql)) {

            Timestamp s = Timestamp.valueOf(start);
            Timestamp e = Timestamp.valueOf(end);

            stmt.setInt(1, hallId);
            stmt.setTimestamp(2, s);
            stmt.setTimestamp(3, s);
            stmt.setTimestamp(4, e);
            stmt.setTimestamp(5, e);
            stmt.setTimestamp(6, s);
            stmt.setTimestamp(7, e);

            ResultSet rs = stmt.executeQuery();
            if (rs.next()) {
                return rs.getInt(1) > 0;
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
        return false;
    }
}
