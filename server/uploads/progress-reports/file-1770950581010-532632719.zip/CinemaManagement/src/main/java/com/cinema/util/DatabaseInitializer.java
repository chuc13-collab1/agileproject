package com.cinema.util;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Statement;
import java.io.File;

public class DatabaseInitializer {

    public static void main(String[] args) {
        System.out.println("Initializing Database...");

        // Ensure DatabaseConnection can connect (might need to strip DB name from URL
        // if DB doesn't exist yet,
        // but for now assume DB exists or URL handles it)

        try (Connection conn = DatabaseConnection.getConnection();
                Statement stmt = conn.createStatement()) {

            // Run schema.sql
            runScript(conn, "database/schema.sql");

            // Run sample_data.sql
            runScript(conn, "database/sample_data.sql");

            System.out.println("Database initialization completed successfully.");

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private static void runScript(Connection conn, String filePath) throws IOException, SQLException {
        File file = new File(filePath);
        if (!file.exists()) {
            System.err.println("File not found: " + filePath);
            return;
        }

        System.out.println("Executing " + filePath + "...");

        StringBuilder sb = new StringBuilder();
        try (BufferedReader br = new BufferedReader(new FileReader(file))) {
            String line;
            while ((line = br.readLine()) != null) {
                // Remove comments
                if (line.trim().startsWith("--") || line.trim().isEmpty()) {
                    continue;
                }
                sb.append(line).append("\n");

                // Very basic fallback: split by semicolon if at end of line
                if (line.trim().endsWith(";")) {
                    String sql = sb.toString().trim();
                    if (!sql.isEmpty()) {
                        try (Statement stmt = conn.createStatement()) {
                            stmt.execute(sql);
                        } catch (SQLException ex) {
                            System.err.println("Error executing statement: " + sql);
                            System.err.println("Message: " + ex.getMessage());
                            // Continue despite errors (e.g. duplicate key)
                        }
                    }
                    sb.setLength(0);
                }
            }
        }
    }
}
