package com.cinema.dao;

import com.cinema.util.DatabaseConnection;

import java.math.BigDecimal;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class TicketDAO {

    // Transactional Booking - Returns Booking ID or -1 if failed
    public int createBooking(int staffId, int showtimeId, List<Integer> seatIds, BigDecimal totalPrice,
            Integer memberId) {
        Connection conn = null;
        try {
            conn = DatabaseConnection.getConnection();
            conn.setAutoCommit(false); // Start Transaction

            // 1. Create Booking Record
            String sqlBooking = "INSERT INTO Bookings (StaffID, TotalAmount, Status, MemberID) VALUES (?, ?, 'PAID', ?)";
            int bookingId = -1;

            try (PreparedStatement stmt = conn.prepareStatement(sqlBooking, Statement.RETURN_GENERATED_KEYS)) {
                stmt.setInt(1, staffId);
                stmt.setBigDecimal(2, totalPrice);
                if (memberId != null) {
                    stmt.setInt(3, memberId);
                } else {
                    stmt.setNull(3, Types.INTEGER);
                }
                stmt.executeUpdate();

                ResultSet rs = stmt.getGeneratedKeys();
                if (rs.next()) {
                    bookingId = rs.getInt(1);
                }
            }

            if (bookingId == -1) {
                conn.rollback();
                return -1;
            }

            // 2. Insert Tickets
            String sqlTicket = "INSERT INTO Tickets (BookingID, ShowtimeID, SeatID, Price) VALUES (?, ?, ?, ?)";
            BigDecimal unitPrice = totalPrice.divide(BigDecimal.valueOf(seatIds.size()), 2,
                    java.math.RoundingMode.HALF_UP);

            try (PreparedStatement stmt = conn.prepareStatement(sqlTicket)) {
                for (Integer seatId : seatIds) {
                    stmt.setInt(1, bookingId);
                    stmt.setInt(2, showtimeId);
                    stmt.setInt(3, seatId);
                    stmt.setBigDecimal(4, unitPrice);
                    stmt.addBatch();
                }
                stmt.executeBatch();
            }

            // 3. Update Member Points if MemberID is present
            if (memberId != null && memberId > 0) {
                // 10,000 VND = 1 Point
                int pointsEarned = totalPrice.divide(BigDecimal.valueOf(10000), 0, java.math.RoundingMode.FLOOR)
                        .intValue();
                String sqlUpdatePoints = "UPDATE Members SET Points = Points + ? WHERE MemberID = ?";
                try (PreparedStatement stmt = conn.prepareStatement(sqlUpdatePoints)) {
                    stmt.setInt(1, pointsEarned);
                    stmt.setInt(2, memberId);
                    int rows = stmt.executeUpdate();
                    System.out.println(
                            "Points Update: Member=" + memberId + ", Earned=" + pointsEarned + ", Rows=" + rows);
                }
            }

            conn.commit(); // Commit Transaction
            return bookingId;

        } catch (SQLException e) {
            e.printStackTrace();
            if (conn != null) {
                try {
                    conn.rollback();
                } catch (SQLException ex) {
                    ex.printStackTrace();
                }
            }
            return -1;
        } finally {
            if (conn != null) {
                try {
                    conn.setAutoCommit(true);
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }
        }
    }

    // Fetch all bookings (for history/refunds)
    public List<BookingRecord> getAllBookings() {
        List<BookingRecord> list = new ArrayList<>();
        // Join Tickets -> Showtimes -> Movies to get Title.
        // Group by BookingID to avoid duplicates (assuming 1 booking = 1 showtime
        // context usually, or just pick one)
        String sql = "SELECT b.BookingID, b.BookingDate, b.TotalAmount, b.Status, u.FullName as StaffName, m.Title as MovieTitle "
                +
                "FROM Bookings b " +
                "LEFT JOIN Users u ON b.StaffID = u.UserID " +
                "LEFT JOIN (SELECT BookingID, ShowtimeID FROM Tickets GROUP BY BookingID) t_group ON b.BookingID = t_group.BookingID "
                +
                "LEFT JOIN Showtimes s ON t_group.ShowtimeID = s.ShowtimeID " +
                "LEFT JOIN Movies m ON s.MovieID = m.MovieID " +
                "ORDER BY b.BookingDate DESC";

        try (Connection conn = DatabaseConnection.getConnection();
                PreparedStatement stmt = conn.prepareStatement(sql);
                ResultSet rs = stmt.executeQuery()) {

            while (rs.next()) {
                BookingRecord r = new BookingRecord();
                r.setId(rs.getInt("BookingID"));
                Timestamp ts = rs.getTimestamp("BookingDate");
                r.setBookingDate(ts != null ? ts.toLocalDateTime() : null);
                r.setTotalAmount(rs.getBigDecimal("TotalAmount"));
                r.setStatus(rs.getString("Status"));
                r.setStaffName(rs.getString("StaffName"));
                r.setMovieTitle(rs.getString("MovieTitle"));
                list.add(r);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return list;
    }

    // Refund Booking (mark as REFUNDED and release seats?)
    public boolean refundBooking(int bookingId) {
        String sql = "UPDATE Bookings SET Status = 'REFUNDED' WHERE BookingID = ?";
        try (Connection conn = DatabaseConnection.getConnection();
                PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setInt(1, bookingId);
            return stmt.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    // Inner DTO for Booking Record
    public static class BookingRecord {
        private int id;
        private java.time.LocalDateTime bookingDate;
        private BigDecimal totalAmount;
        private String status;
        private String staffName;
        private String movieTitle;

        // Getters/Setters
        public int getId() {
            return id;
        }

        public void setId(int id) {
            this.id = id;
        }

        public java.time.LocalDateTime getBookingDate() {
            return bookingDate;
        }

        public void setBookingDate(java.time.LocalDateTime d) {
            this.bookingDate = d;
        }

        public BigDecimal getTotalAmount() {
            return totalAmount;
        }

        public void setTotalAmount(BigDecimal t) {
            this.totalAmount = t;
        }

        public String getStatus() {
            return status;
        }

        public void setStatus(String s) {
            this.status = s;
        }

        public String getStaffName() {
            return staffName;
        }

        public void setStaffName(String s) {
            this.staffName = s;
        }

        public String getMovieTitle() {
            return movieTitle;
        }

        public void setMovieTitle(String m) {
            this.movieTitle = m;
        }
    }
}
