package com.cinema.ui.content;

import com.cinema.dao.MemberDAO;
import com.cinema.model.Member;
import com.cinema.dao.SeatDAO;
import com.cinema.dao.ShowtimeDAO;
import com.cinema.dao.TicketDAO;
import com.cinema.model.Seat;
import com.cinema.model.Showtime;
import com.cinema.model.User;
import com.cinema.ui.MainFrame;
import com.formdev.flatlaf.FlatClientProperties;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;
import java.awt.event.ActionListener;
import java.math.BigDecimal;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;

public class TicketSalesPanel extends JPanel {

    private MainFrame mainFrame;
    private User currentUser;

    // DAOs
    private ShowtimeDAO showtimeDAO;
    private SeatDAO seatDAO;
    private TicketDAO ticketDAO;

    // Components
    private JComboBox<Showtime> cmbShowtimes;
    private JPanel seatMapPanel;

    // State
    private List<Integer> selectedSeats = new ArrayList<>();
    private Showtime currentShowtime;

    public TicketSalesPanel(MainFrame frame, User user) {
        this.mainFrame = frame;
        this.currentUser = user;

        showtimeDAO = new ShowtimeDAO();
        seatDAO = new SeatDAO();
        ticketDAO = new TicketDAO();

        initComponents();
        loadShowtimes();
    }

    public TicketSalesPanel() {
        this(null, null);
    }

    private void initComponents() {
        setLayout(new BorderLayout());
        setBackground(new Color(40, 42, 54));

        // --- Top Bar: Select Showtime ---
        JPanel topPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        topPanel.setOpaque(false);
        topPanel.setBorder(new EmptyBorder(10, 20, 10, 20));

        JLabel lblShow = new JLabel("Chọn Suất Chiếu:");
        lblShow.setForeground(Color.WHITE);
        lblShow.setFont(new Font("SansSerif", Font.BOLD, 14));

        cmbShowtimes = new JComboBox<>();
        cmbShowtimes.setPreferredSize(new Dimension(350, 30));
        cmbShowtimes.addActionListener(e -> loadSeatMap());

        JButton btnRefresh = new JButton("Refresh");
        btnRefresh.addActionListener(e -> loadShowtimes()); // Reload list

        topPanel.add(lblShow);
        topPanel.add(cmbShowtimes);
        topPanel.add(btnRefresh);

        add(topPanel, BorderLayout.NORTH);

        // --- Center: Seat Map ---
        seatMapPanel = new JPanel();
        seatMapPanel.setLayout(new GridBagLayout()); // Use GridBag for centering grid
        seatMapPanel.setBackground(new Color(45, 48, 60));
        JScrollPane scroll = new JScrollPane(seatMapPanel);
        scroll.setBorder(null);

        add(scroll, BorderLayout.CENTER);

        // Initialize Sidebar
        SwingUtilities.invokeLater(this::updateSidebar);

        // Restore Sidebar when panel becomes visible again
        this.addComponentListener(new java.awt.event.ComponentAdapter() {
            @Override
            public void componentShown(java.awt.event.ComponentEvent e) {
                updateSidebar();
            }
        });
    }

    private void loadShowtimes() {
        cmbShowtimes.removeAllItems();
        List<Showtime> list = showtimeDAO.getAllShowtimes();

        cmbShowtimes.setRenderer(new DefaultListCellRenderer() {
            @Override
            public Component getListCellRendererComponent(JList<?> list, Object value, int index, boolean isSelected,
                    boolean cellHasFocus) {
                super.getListCellRendererComponent(list, value, index, isSelected, cellHasFocus);
                if (value instanceof Showtime) {
                    Showtime s = (Showtime) value;
                    setText(s.getMovieTitle() + " | "
                            + s.getStartTime().format(DateTimeFormatter.ofPattern("HH:mm dd/MM")) + " | "
                            + s.getHallName());
                }
                return this;
            }
        });

        for (Showtime s : list) {
            cmbShowtimes.addItem(s);
        }
    }

    // Field for seats
    private List<Seat> currentHallSeats;

    private void loadSeatMap() {
        seatMapPanel.removeAll();
        selectedSeats.clear();
        updateSidebar();

        currentShowtime = (Showtime) cmbShowtimes.getSelectedItem();
        if (currentShowtime == null) {
            seatMapPanel.revalidate();
            seatMapPanel.repaint();
            return;
        }

        // 1. Get Hall Layout AND Store in Field
        currentHallSeats = seatDAO.getSeatsByHallId(currentShowtime.getHallId());

        // 2. Get Booked Seats
        List<Integer> booked = seatDAO.getBookedSeatIds(currentShowtime.getShowtimeId());

        // 3. Render Grid
        if (currentHallSeats.isEmpty()) {
            seatMapPanel.add(new JLabel("Chưa có sơ đồ ghế cho phòng này!"));
            seatMapPanel.revalidate();
            seatMapPanel.repaint();
            return;
        }

        // Find max rows/cols to set GridLayout
        int maxRow = 0;
        int maxCol = 0;
        for (Seat s : currentHallSeats) {
            // RowLabel 'A' -> 1
            if (s.getRowLabel() == null || s.getRowLabel().isEmpty())
                continue;
            int r = s.getRowLabel().charAt(0) - 'A' + 1;
            if (r > maxRow)
                maxRow = r;
            if (s.getSeatNumber() > maxCol)
                maxCol = s.getSeatNumber();
        }

        if (maxRow == 0 || maxCol == 0) {
            seatMapPanel.add(new JLabel("Dữ liệu ghế không hợp lệ!"));
            seatMapPanel.revalidate();
            seatMapPanel.repaint();
            return;
        }

        JPanel grid = new JPanel(new GridLayout(maxRow, maxCol, 5, 5));
        grid.setOpaque(false);

        for (int r = 1; r <= maxRow; r++) {
            String rowChar = String.valueOf((char) ('A' + r - 1));
            for (int c = 1; c <= maxCol; c++) {
                final String currentRow = rowChar;
                final int currentNum = c;

                Seat seat = currentHallSeats.stream()
                        .filter(s -> s.getRowLabel().equals(currentRow) && s.getSeatNumber() == currentNum)
                        .findFirst().orElse(null);

                if (seat != null) {
                    JToggleButton btn = new JToggleButton(rowChar + c);
                    btn.setPreferredSize(new Dimension(50, 40));
                    btn.setFont(new Font("SansSerif", Font.BOLD, 14));
                    btn.setFocusPainted(false);
                    btn.setBorder(BorderFactory.createLineBorder(Color.BLACK));

                    if (booked.contains(seat.getSeatId())) {
                        btn.setBackground(Color.DARK_GRAY);
                        btn.setForeground(Color.GRAY);
                        btn.setEnabled(false); // Booked
                    } else if ("VIP".equalsIgnoreCase(seat.getSeatType())) {
                        btn.setBackground(new Color(255, 165, 0)); // Bright Orange
                        btn.setForeground(Color.BLACK);
                        btn.setToolTipText("Ghế VIP (+20k)");
                    } else {
                        btn.setBackground(new Color(100, 149, 237)); // Cornflower Blue
                        btn.setForeground(Color.WHITE);
                        btn.setToolTipText("Ghế Thường");
                    }

                    // Selection Logic
                    btn.addActionListener(e -> {
                        if (btn.isSelected()) {
                            selectedSeats.add(seat.getSeatId());
                            btn.setBackground(Color.GREEN);
                            btn.setForeground(Color.BLACK);
                        } else {
                            selectedSeats.remove(Integer.valueOf(seat.getSeatId()));
                            // Restore color
                            if ("VIP".equalsIgnoreCase(seat.getSeatType())) {
                                btn.setBackground(new Color(255, 165, 0));
                                btn.setForeground(Color.BLACK);
                            } else {
                                btn.setBackground(new Color(100, 149, 237));
                                btn.setForeground(Color.WHITE);
                            }
                        }
                        updateSidebar();
                    });

                    grid.add(btn);
                } else {
                    // Gap
                    grid.add(Box.createGlue());
                }
            }
        }

        // Screen Label
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.gridx = 0;
        gbc.gridy = 0;
        gbc.insets = new Insets(0, 0, 30, 0);
        JLabel screen = new JLabel("MÀN HÌNH", SwingConstants.CENTER);
        screen.setOpaque(true);
        screen.setBackground(Color.WHITE);
        screen.setPreferredSize(new Dimension(400, 30));
        seatMapPanel.add(screen, gbc);

        gbc.gridy = 1;
        seatMapPanel.add(grid, gbc);

        seatMapPanel.revalidate();
        seatMapPanel.repaint();
    }

    // Member Integration
    private Member currentMember = null;
    private JLabel lblMemberInfo;

    // ...

    private void updateSidebar() {
        if (mainFrame == null)
            return;

        JPanel panel = new JPanel();
        panel.setLayout(new BoxLayout(panel, BoxLayout.Y_AXIS));
        panel.setOpaque(false);

        JLabel title = new JLabel("Thông Tin Đặt Vé");
        title.setFont(new Font("SansSerif", Font.BOLD, 20));
        title.setForeground(Color.CYAN);
        title.setAlignmentX(Component.LEFT_ALIGNMENT);
        panel.add(title);
        panel.add(Box.createVerticalStrut(20));

        // --- Member Section (NEW) ---
        JPanel memberPanel = new JPanel(new BorderLayout(5, 5));
        memberPanel.setOpaque(false);
        memberPanel.setAlignmentX(Component.LEFT_ALIGNMENT);
        memberPanel.setMaximumSize(new Dimension(300, 80));

        JTextField txtPhone = new JTextField();
        txtPhone.putClientProperty(FlatClientProperties.PLACEHOLDER_TEXT, "Nhập SĐT khách...");

        JButton btnFind = new JButton("Tìm");
        btnFind.addActionListener(e -> {
            String phone = txtPhone.getText().trim();
            if (!phone.isEmpty()) {
                currentMember = new MemberDAO().searchMembers(phone).stream()
                        .filter(m -> m.getPhoneNumber().equals(phone))
                        .findFirst().orElse(null);
                if (currentMember != null) {
                    lblMemberInfo.setText("<html><b style='color:#50fa7b'>" + currentMember.getFullName() +
                            "</b><br><span style='color:#f1fa8c'>" + currentMember.getMembershipLevel() + " ("
                            + currentMember.getPoints() + " pts)</span></html>");
                    lblMemberInfo.setVisible(true);
                } else {
                    lblMemberInfo.setText("Không tìm thấy khách hàng!");
                    lblMemberInfo.setForeground(Color.ORANGE);
                    lblMemberInfo.setVisible(true);
                    currentMember = null;
                }
            }
        });

        JPanel findBox = new JPanel(new BorderLayout());
        findBox.setOpaque(false);
        findBox.add(txtPhone, BorderLayout.CENTER);
        findBox.add(btnFind, BorderLayout.EAST);

        memberPanel.add(new JLabel("Thành Viên:"), BorderLayout.NORTH);
        memberPanel.add(findBox, BorderLayout.CENTER);

        lblMemberInfo = new JLabel();
        lblMemberInfo.setVisible(false);
        memberPanel.add(lblMemberInfo, BorderLayout.SOUTH);

        panel.add(memberPanel);
        panel.add(Box.createVerticalStrut(20));
        // -----------------------------

        if (currentShowtime != null) {
            addInfoRow(panel, "Phim:", currentShowtime.getMovieTitle());
            addInfoRow(panel, "Suất:",
                    currentShowtime.getStartTime().format(DateTimeFormatter.ofPattern("HH:mm dd/MM")));
            addInfoRow(panel, "Phòng:", currentShowtime.getHallName());
            panel.add(Box.createVerticalStrut(20));
        }

        int standardCount = 0;
        int vipCount = 0;
        BigDecimal total = BigDecimal.ZERO;

        if (currentShowtime != null && currentHallSeats != null) {
            BigDecimal basePrice = currentShowtime.getBasePrice();
            BigDecimal vipPrice = basePrice.add(BigDecimal.valueOf(20000));

            for (Integer id : selectedSeats) {
                Seat s = currentHallSeats.stream().filter(seat -> seat.getSeatId() == id).findFirst().orElse(null);
                if (s != null) {
                    if ("VIP".equalsIgnoreCase(s.getSeatType())) {
                        vipCount++;
                        total = total.add(vipPrice);
                    } else {
                        standardCount++;
                        total = total.add(basePrice);
                    }
                }
            }
        }

        if (standardCount > 0)
            addInfoRow(panel, "Ghế Thường:", String.valueOf(standardCount));
        if (vipCount > 0)
            addInfoRow(panel, "Ghế VIP (+20k):", String.valueOf(vipCount));

        panel.add(Box.createVerticalStrut(10));
        JLabel totalLbl = new JLabel("Tổng tiền:");
        totalLbl.setForeground(Color.GRAY);
        totalLbl.setAlignmentX(Component.LEFT_ALIGNMENT);
        panel.add(totalLbl);

        JLabel priceLbl = new JLabel(String.format("%,.0f VNĐ", total));
        priceLbl.setForeground(new Color(80, 250, 123)); // Green
        priceLbl.setFont(new Font("SansSerif", Font.BOLD, 24));
        priceLbl.setAlignmentX(Component.LEFT_ALIGNMENT);
        panel.add(priceLbl);

        panel.add(Box.createVerticalStrut(30));

        JButton btnPay = new JButton("Thanh Toán & In Vé");
        btnPay.setBackground(new Color(255, 85, 85));
        btnPay.setForeground(Color.WHITE);
        btnPay.setFont(new Font("SansSerif", Font.BOLD, 16));
        btnPay.setMaximumSize(new Dimension(Integer.MAX_VALUE, 50));
        btnPay.setAlignmentX(Component.LEFT_ALIGNMENT);
        btnPay.setEnabled(!selectedSeats.isEmpty());
        // Need to pass actual total for booking
        BigDecimal finalTotal = total;
        btnPay.addActionListener(e -> processBooking(finalTotal));

        panel.add(btnPay);

        mainFrame.setRightSidebarContent(panel);
    }

    private void addInfoRow(JPanel p, String label, String value) {
        JPanel row = new JPanel(new BorderLayout());
        row.setOpaque(false);
        row.setMaximumSize(new Dimension(300, 25));
        row.setAlignmentX(Component.LEFT_ALIGNMENT);

        JLabel l = new JLabel(label);
        l.setForeground(Color.LIGHT_GRAY);
        JLabel v = new JLabel(value);
        v.setForeground(Color.WHITE);
        v.setFont(new Font("SansSerif", Font.BOLD, 13));

        row.add(l, BorderLayout.WEST);
        row.add(v, BorderLayout.EAST);
        p.add(row);
        p.add(Box.createVerticalStrut(5));
    }

    // Updated signature for processBooking
    private void processBooking(BigDecimal totalAmount) {
        if (currentUser == null) {
            currentUser = new User();
            currentUser.setUserId(1);
        }

        int confirm = JOptionPane.showConfirmDialog(this,
                "Xác nhận thanh toán " + String.format("%,.0f VNĐ", totalAmount) + "?",
                "Xác nhận", JOptionPane.YES_NO_OPTION);

        if (confirm == JOptionPane.YES_OPTION) {
            // Updated to pass currentMember ID if exists
            Integer memId = currentMember != null ? currentMember.getMemberId() : null;

            int bookingId = ticketDAO.createBooking(currentUser.getUserId(), currentShowtime.getShowtimeId(),
                    selectedSeats, totalAmount, memId);

            if (bookingId != -1) {
                showReceiptDialog(bookingId, totalAmount);
                selectedSeats.clear();
                // Reset member info
                currentMember = null;
                if (lblMemberInfo != null)
                    lblMemberInfo.setText("");

                loadSeatMap();
            } else {
                JOptionPane.showMessageDialog(this, "Lỗi thanh toán!", "Lỗi", JOptionPane.ERROR_MESSAGE);
            }
        }
    }

    private void showReceiptDialog(int bookingId, BigDecimal total) {
        StringBuilder sb = new StringBuilder();
        sb.append("<html><body style='width: 300px; padding: 10px;'>");
        sb.append("<h2 style='text-align:center;'>HÓA ĐƠN THANH TOÁN</h2>");
        sb.append("<hr>");
        sb.append("<b>Mã hóa đơn:</b> #").append(bookingId).append("<br>");
        sb.append("<b>Phim:</b> ").append(currentShowtime.getMovieTitle()).append("<br>");
        sb.append("<b>Suất chiếu:</b> ")
                .append(currentShowtime.getStartTime().format(DateTimeFormatter.ofPattern("HH:mm dd/MM/yyyy")))
                .append("<br>");
        sb.append("<b>Phòng:</b> ").append(currentShowtime.getHallName()).append("<br><br>");

        if (currentMember != null) {
            sb.append("<b>Thành viên:</b> ").append(currentMember.getFullName()).append("<br>");
            // Calculate points earned: 10k = 1 point
            int points = total.divide(BigDecimal.valueOf(10000), 0, java.math.RoundingMode.FLOOR).intValue();
            sb.append("<b>Tích điểm:</b> +").append(points).append(" pts<br><br>");
        }

        sb.append("<b>Ghế:</b> ");
        List<String> seatLabels = new ArrayList<>();
        // Re-fetch labels from currentHallSeats
        for (Integer id : selectedSeats) {
            Seat s = currentHallSeats.stream().filter(seat -> seat.getSeatId() == id).findFirst().orElse(null);
            if (s != null)
                seatLabels.add(s.toString());
        }
        sb.append(String.join(", ", seatLabels)).append("<br>");

        sb.append("<br><b>Tổng cộng:</b> <span style='color:red; font-size:14px;'>")
                .append(String.format("%,.0f VNĐ", total)).append("</span>");

        sb.append("<hr>");
        sb.append("<p style='text-align:center; font-style:italic;'>Cảm ơn quý khách!</p>");
        sb.append("</body></html>");

        JOptionPane.showMessageDialog(this, sb.toString(), "In Vé Thành Công", JOptionPane.INFORMATION_MESSAGE);
    }
}
