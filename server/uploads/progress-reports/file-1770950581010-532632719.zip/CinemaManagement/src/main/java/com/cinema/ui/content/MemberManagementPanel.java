package com.cinema.ui.content;

import com.cinema.dao.MemberDAO;
import com.cinema.model.Member;
import com.formdev.flatlaf.FlatClientProperties;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.List;

public class MemberManagementPanel extends JPanel {

    private JTable table;
    private DefaultTableModel tableModel;
    private MemberDAO memberDAO;
    private JTextField searchField;

    public MemberManagementPanel() {
        this.memberDAO = new MemberDAO();
        initComponents();
        loadMembers();
    }

    private void initComponents() {
        setLayout(new BorderLayout(20, 20));
        setBackground(new Color(40, 42, 54));
        setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));

        // Header
        JPanel header = new JPanel(new BorderLayout());
        header.setOpaque(false);
        JLabel title = new JLabel("Quản Lý Thành Viên");
        title.setFont(new Font("SansSerif", Font.BOLD, 24));
        title.setForeground(Color.WHITE);
        header.add(title, BorderLayout.WEST);

        // Toolbar
        JPanel toolbar = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        toolbar.setOpaque(false);

        searchField = new JTextField(15);
        searchField.putClientProperty(FlatClientProperties.PLACEHOLDER_TEXT, "Tìm theo tên/SĐT...");
        JButton btnSearch = new JButton("Tìm kiếm");
        btnSearch.addActionListener(e -> searchMembers());

        JButton btnAdd = new JButton("Thêm Mới");
        btnAdd.setBackground(new Color(80, 250, 123));
        btnAdd.setForeground(Color.BLACK);
        btnAdd.addActionListener(e -> showMemberDialog(null));

        JButton btnEdit = new JButton("Sửa");
        btnEdit.addActionListener(e -> {
            Member m = getSelectedMember();
            if (m != null)
                showMemberDialog(m);
        });

        JButton btnDelete = new JButton("Xóa");
        btnDelete.setBackground(new Color(255, 85, 85));
        btnDelete.setForeground(Color.WHITE);
        btnDelete.addActionListener(e -> deleteMember());

        toolbar.add(searchField);
        toolbar.add(btnSearch);

        JButton btnRefresh = new JButton("Làm mới");
        btnRefresh.addActionListener(e -> {
            searchField.setText("");
            loadMembers();
        });
        toolbar.add(Box.createHorizontalStrut(5));
        toolbar.add(btnRefresh);

        toolbar.add(Box.createHorizontalStrut(20));
        toolbar.add(btnAdd);
        toolbar.add(btnEdit);
        toolbar.add(btnDelete);

        header.add(toolbar, BorderLayout.EAST);
        add(header, BorderLayout.NORTH);

        // Table
        String[] cols = { "ID", "Họ Tên", "Giới tính", "SĐT", "Hạng", "Điểm" };
        tableModel = new DefaultTableModel(cols, 0) {
            @Override
            public boolean isCellEditable(int row, int col) {
                return false;
            }
        };
        table = new JTable(tableModel);
        table.setRowHeight(30);

        JScrollPane scroll = new JScrollPane(table);
        scroll.getViewport().setBackground(new Color(40, 42, 54));
        add(scroll, BorderLayout.CENTER);
    }

    private void loadMembers() {
        updateTable(memberDAO.getAllMembers());
    }

    private void searchMembers() {
        String kw = searchField.getText().trim();
        if (kw.isEmpty())
            loadMembers();
        else
            updateTable(memberDAO.searchMembers(kw));
    }

    private void updateTable(List<Member> list) {
        tableModel.setRowCount(0);
        for (Member m : list) {
            tableModel.addRow(new Object[] {
                    m.getMemberId(),
                    m.getFullName(),
                    m.getGender(),
                    m.getPhoneNumber(),
                    m.getMembershipLevel(),
                    m.getPoints()
            });
        }
    }

    private Member getSelectedMember() {
        int r = table.getSelectedRow();
        if (r == -1) {
            JOptionPane.showMessageDialog(this, "Vui lòng chọn thành viên!");
            return null;
        }
        int id = (int) tableModel.getValueAt(r, 0);
        // fetch full detail or iterate list if needed, but DAO get by ID isn't impld
        // yet
        // For now, simpler to find from current list or just rely on DAO search not
        // refreshing too fast
        // Let's implement basics. Just re-fetch simple search?
        // Actually, we need the full object for editing.
        // Hack: I'll trust the ID and find it in the current loaded list if I kept it?
        // Or adding `getMemberById` to DAO is better.
        // For MVP, I'll filter from getAllMembers()
        return memberDAO.getAllMembers().stream().filter(m -> m.getMemberId() == id).findFirst().orElse(null);
    }

    private void deleteMember() {
        Member m = getSelectedMember();
        if (m != null) {
            int cf = JOptionPane.showConfirmDialog(this, "Xóa thành viên " + m.getFullName() + "?");
            if (cf == JOptionPane.YES_OPTION) {
                if (memberDAO.deleteMember(m.getMemberId())) {
                    JOptionPane.showMessageDialog(this, "Đã xóa!");
                    loadMembers();
                } else {
                    JOptionPane.showMessageDialog(this, "Lỗi khi xóa!");
                }
            }
        }
    }

    private void showMemberDialog(Member member) {
        JDialog d = new JDialog((Frame) SwingUtilities.getWindowAncestor(this),
                member == null ? "Thêm Thành Viên" : "Sửa Thành Viên", true);
        d.setLayout(new GridBagLayout());
        d.setSize(400, 500);
        d.setLocationRelativeTo(this);

        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(10, 10, 10, 10);
        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.gridx = 0;
        gbc.gridy = 0;

        JTextField txtName = new JTextField(20);
        JTextField txtPhone = new JTextField(20);
        JTextField txtEmail = new JTextField(20);
        JTextField txtAddress = new JTextField(20);
        JComboBox<String> cbGender = new JComboBox<>(new String[] { "Male", "Female", "Other" });
        JComboBox<String> cbLevel = new JComboBox<>(new String[] { "Standard", "VIP", "Platinum" });
        // Date picker simplifying to text for MVP or JSpinner? Text YYYY-MM-DD
        JTextField txtDOB = new JTextField(20);
        txtDOB.setToolTipText("YYYY-MM-DD");

        if (member != null) {
            txtName.setText(member.getFullName());
            txtPhone.setText(member.getPhoneNumber());
            txtEmail.setText(member.getEmail());
            txtAddress.setText(member.getAddress());
            cbGender.setSelectedItem(member.getGender());
            cbLevel.setSelectedItem(member.getMembershipLevel());
            if (member.getDateOfBirth() != null)
                txtDOB.setText(member.getDateOfBirth().toString());
        }

        d.add(new JLabel("Họ Tên:"), gbc);
        gbc.gridx = 1;
        d.add(txtName, gbc);
        gbc.gridx = 0;
        gbc.gridy++;
        d.add(new JLabel("SĐT:"), gbc);
        gbc.gridx = 1;
        d.add(txtPhone, gbc);
        gbc.gridx = 0;
        gbc.gridy++;
        d.add(new JLabel("Email:"), gbc);
        gbc.gridx = 1;
        d.add(txtEmail, gbc);
        gbc.gridx = 0;
        gbc.gridy++;
        d.add(new JLabel("Ngày Sinh (YYYY-MM-DD):"), gbc);
        gbc.gridx = 1;
        d.add(txtDOB, gbc);
        gbc.gridx = 0;
        gbc.gridy++;
        d.add(new JLabel("Giới tính:"), gbc);
        gbc.gridx = 1;
        d.add(cbGender, gbc);
        gbc.gridx = 0;
        gbc.gridy++;
        d.add(new JLabel("Địa chỉ:"), gbc);
        gbc.gridx = 1;
        d.add(txtAddress, gbc);
        gbc.gridx = 0;
        gbc.gridy++;
        d.add(new JLabel("Hạng:"), gbc);
        gbc.gridx = 1;
        d.add(cbLevel, gbc);

        JPanel btnP = new JPanel();
        JButton btnSave = new JButton("Lưu");
        JButton btnCancel = new JButton("Hủy");
        btnP.add(btnSave);
        btnP.add(btnCancel);

        gbc.gridx = 0;
        gbc.gridy++;
        gbc.gridwidth = 2;
        d.add(btnP, gbc);

        btnCancel.addActionListener(e -> d.dispose());
        btnSave.addActionListener(e -> {
            try {
                String name = txtName.getText().trim();
                String phone = txtPhone.getText().trim();
                if (name.isEmpty() || phone.isEmpty()) {
                    JOptionPane.showMessageDialog(d, "Tên và SĐT là bắt buộc!");
                    return;
                }

                Member m = member != null ? member : new Member();
                m.setFullName(name);
                m.setPhoneNumber(phone);
                m.setEmail(txtEmail.getText().trim());
                m.setAddress(txtAddress.getText().trim());
                m.setGender((String) cbGender.getSelectedItem());
                m.setMembershipLevel((String) cbLevel.getSelectedItem());

                String dobStr = txtDOB.getText().trim();
                if (!dobStr.isEmpty()) {
                    m.setDateOfBirth(LocalDate.parse(dobStr));
                }

                boolean success;
                if (member == null)
                    success = memberDAO.addMember(m);
                else
                    success = memberDAO.updateMember(m);

                if (success) {
                    JOptionPane.showMessageDialog(d, "Lưu thành công!");
                    d.dispose();
                    loadMembers();
                } else {
                    JOptionPane.showMessageDialog(d, "Lỗi khi lưu (Kiểm tra xem SĐT có trùng không?)");
                }
            } catch (Exception ex) {
                JOptionPane.showMessageDialog(d, "Lỗi định dạng: " + ex.getMessage());
            }
        });

        d.setVisible(true);
    }
}
