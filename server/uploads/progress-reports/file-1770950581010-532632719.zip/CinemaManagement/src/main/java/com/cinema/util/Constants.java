package com.cinema.util;

/**
 * Application constants
 */
public class Constants {

    // Roles
    public static final String ROLE_ADMIN = "ADMIN";
    public static final String ROLE_STAFF = "STAFF";

    // Movie Status
    public static final String STATUS_COMING_SOON = "COMING_SOON";
    public static final String STATUS_SHOWING = "SHOWING";
    public static final String STATUS_STOPPED = "STOPPED";

    // Paths
    public static final String POSTER_PATH = "media/posters/";

}
