package com.cinema.ui;

import com.cinema.model.User;
import com.cinema.ui.dashboard.DashboardPanel;
import com.cinema.ui.content.BookingHistoryPanel;
import com.cinema.ui.content.CinemaHallPanel;
import com.cinema.ui.content.MemberManagementPanel;
import com.cinema.ui.content.MemberManagementPanel;
import com.cinema.ui.content.MovieManagementPanel;
import com.cinema.ui.content.ReportPanel;
import com.cinema.ui.content.SchedulePanel;
import com.cinema.ui.content.StaffManagementPanel;
import com.cinema.ui.content.TicketSalesPanel;
import com.formdev.flatlaf.FlatClientProperties;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;
import java.util.HashMap;
import java.util.Map;

/**
 * Main application window with 3-column layout (Mov.time style)
 * Implements Role-Based Access Control and CardLayout Navigation
 */
public class MainFrame extends JFrame {

    private final User currentUser;
    private JPanel centerPanel;
    private CardLayout cardLayout;
    private final Map<String, JButton> menuButtons = new HashMap<>();

    public MainFrame(User user) {
        this.currentUser = user;
        initComponents();
    }

    public MainFrame() {
        this.currentUser = new User();
        this.currentUser.setRole("ADMIN");
        this.currentUser.setFullName("Test Admin");
        initComponents();
    }

    private void initComponents() {
        setTitle("Cinema Management System - Dashboard");
        setSize(1400, 900);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        JPanel root = new JPanel(new BorderLayout());
        root.setBackground(new Color(40, 42, 54));
        setContentPane(root);

        root.add(createLeftSidebar(), BorderLayout.WEST);

        // Center Content with CardLayout
        cardLayout = new CardLayout();
        centerPanel = new JPanel(cardLayout);
        centerPanel.setBackground(new Color(40, 42, 54));

        // Add Views
        // Add Views
        centerPanel.add(new DashboardPanel(currentUser), "Dashboard");
        centerPanel.add(new MovieManagementPanel(this), "Movies");
        centerPanel.add(new SchedulePanel(this), "Schedule");
        centerPanel.add(new TicketSalesPanel(this, currentUser), "Sales");
        centerPanel.add(new CinemaHallPanel(), "Halls");
        centerPanel.add(new ReportPanel(), "Reports");
        centerPanel.add(new BookingHistoryPanel(), "Refunds");
        centerPanel.add(new BookingHistoryPanel(), "Refunds");
        centerPanel.add(new MemberManagementPanel(), "Members");
        centerPanel.add(new StaffManagementPanel(), "Staff");

        root.add(centerPanel, BorderLayout.CENTER);

        root.add(createRightSidebar(), BorderLayout.EAST);

        // Show default view
        showView("Dashboard");
    }

    private void showView(String viewName) {
        // Reset Right Sidebar to default first
        resetRightSidebar();

        cardLayout.show(centerPanel, viewName);

        // Update active menu state
        for (Map.Entry<String, JButton> entry : menuButtons.entrySet()) {
            JButton btn = entry.getValue();
            if (entry.getKey().equals(viewName)) {
                btn.setForeground(new Color(80, 150, 255));
                btn.setFont(btn.getFont().deriveFont(Font.BOLD));
            } else {
                btn.setForeground(new Color(200, 200, 210));
                btn.setFont(btn.getFont().deriveFont(Font.PLAIN));
            }
        }
    }

    private JPanel createLeftSidebar() {
        JPanel sidebar = new JPanel();
        sidebar.setLayout(new BoxLayout(sidebar, BoxLayout.Y_AXIS));
        sidebar.setBackground(new Color(40, 42, 54));
        sidebar.setPreferredSize(new Dimension(250, getHeight()));
        sidebar.setBorder(new EmptyBorder(30, 20, 30, 20));

        JLabel appName = new JLabel("Mov.time");
        appName.setFont(new Font("SansSerif", Font.BOLD, 24));
        appName.setForeground(new Color(80, 150, 255));
        appName.setAlignmentX(Component.LEFT_ALIGNMENT);

        sidebar.add(appName);
        sidebar.add(Box.createVerticalStrut(40));

        addMenuSection(sidebar, "DANH MỤC");

        // Common Menus
        addMenuButton(sidebar, "Tổng quan", "Dashboard");

        String role = currentUser != null ? currentUser.getRole() : "GUEST";

        if ("ADMIN".equalsIgnoreCase(role)) {
            addMenuButton(sidebar, "Quản lý Phim", "Movies");
            addMenuButton(sidebar, "Lịch chiếu", "Schedule");
            addMenuButton(sidebar, "Phòng chiếu", "Halls");
            addMenuButton(sidebar, "Bán vé", "Sales");
            addMenuButton(sidebar, "Hoàn vé", "Refunds"); // Admin accesses Refunds
            addMenuButton(sidebar, "Nhân viên", "Staff");
            addMenuButton(sidebar, "Báo cáo", "Reports");
        } else if ("STAFF".equalsIgnoreCase(role)) {
            addMenuButton(sidebar, "Bán vé", "Sales");
            addMenuButton(sidebar, "Hoàn vé", "Refunds");
            addMenuButton(sidebar, "Thành viên", "Members");
            addMenuButton(sidebar, "Ca làm việc", "Shift");
        }

        sidebar.add(Box.createVerticalStrut(30));

        addMenuSection(sidebar, "KHÁC");
        addMenuButton(sidebar, "Cài đặt", "Settings");

        JButton logoutBtn = createMenuButton("Đăng xuất");
        logoutBtn.addActionListener(e -> logout());
        sidebar.add(logoutBtn);
        sidebar.add(Box.createVerticalStrut(5));

        return sidebar;
    }

    private void logout() {
        this.dispose();
        new LoginFrame().setVisible(true);
    }

    private void addMenuSection(JPanel panel, String title) {
        JLabel label = new JLabel(title);
        label.setFont(new Font("SansSerif", Font.BOLD, 12));
        label.setForeground(new Color(160, 160, 170));
        label.setAlignmentX(Component.LEFT_ALIGNMENT);
        panel.add(label);
        panel.add(Box.createVerticalStrut(10));
    }

    private void addMenuButton(JPanel panel, String text, String viewName) {
        JButton btn = createMenuButton(text);
        btn.addActionListener(e -> showView(viewName));
        menuButtons.put(viewName, btn);
        panel.add(btn);
        panel.add(Box.createVerticalStrut(5));
    }

    private JButton createMenuButton(String text) {
        JButton btn = new JButton(text);
        btn.setFont(new Font("SansSerif", Font.PLAIN, 15));
        btn.setHorizontalAlignment(SwingConstants.LEFT);
        btn.setBorderPainted(false);
        btn.setFocusPainted(false);
        btn.setContentAreaFilled(false);
        btn.setCursor(new Cursor(Cursor.HAND_CURSOR));
        btn.setMaximumSize(new Dimension(200, 40));
        btn.setAlignmentX(Component.LEFT_ALIGNMENT);
        btn.setForeground(new Color(200, 200, 210));
        return btn;
    }

    private JPanel rightSidebarContainer;

    public void setRightSidebarContent(JComponent component) {
        if (rightSidebarContainer != null) {
            // Keep Profile
            Component profile = rightSidebarContainer.getComponent(0);

            rightSidebarContainer.removeAll();
            rightSidebarContainer.add(profile); // Add profile back
            rightSidebarContainer.add(Box.createVerticalStrut(20));

            // Add new content
            rightSidebarContainer.add(component);

            rightSidebarContainer.revalidate();
            rightSidebarContainer.repaint();
        }
    }

    public void resetRightSidebar() {
        if (rightSidebarContainer != null) {
            rightSidebarContainer.removeAll();

            // Re-create default layout
            JPanel profile = new JPanel(new FlowLayout(FlowLayout.LEFT));
            profile.setOpaque(false);
            profile.setAlignmentX(Component.LEFT_ALIGNMENT);
            JLabel avatar = new JLabel("[Avatar]");
            avatar.setForeground(Color.WHITE);
            String displayName = currentUser != null ? currentUser.getFullName() : "User";
            JLabel name = new JLabel(displayName);
            name.setFont(new Font("SansSerif", Font.BOLD, 14));
            name.setForeground(Color.WHITE);
            profile.add(avatar);
            profile.add(name);
            rightSidebarContainer.add(profile);

            rightSidebarContainer.add(Box.createVerticalStrut(10));
            JLabel roleLabel = new JLabel("Vai trò: " + (currentUser != null ? currentUser.getRole() : "N/A"));
            roleLabel.setForeground(Color.GRAY);
            roleLabel.setAlignmentX(Component.LEFT_ALIGNMENT);
            rightSidebarContainer.add(roleLabel);

            rightSidebarContainer.add(Box.createVerticalStrut(20));

            JTextField search = new JTextField();
            search.putClientProperty(FlatClientProperties.PLACEHOLDER_TEXT, "Tìm kiếm...");
            search.putClientProperty(FlatClientProperties.STYLE,
                    "arc: 20; background: #454859; foreground: #ffffff; borderWidth: 0;");
            search.setMaximumSize(new Dimension(Integer.MAX_VALUE, 40));
            search.setAlignmentX(Component.LEFT_ALIGNMENT);
            rightSidebarContainer.add(search);

            rightSidebarContainer.add(Box.createVerticalGlue());

            rightSidebarContainer.revalidate();
            rightSidebarContainer.repaint();
        }
    }

    private JPanel createRightSidebar() {
        rightSidebarContainer = new JPanel();
        rightSidebarContainer.setLayout(new BoxLayout(rightSidebarContainer, BoxLayout.Y_AXIS));
        rightSidebarContainer.setBackground(new Color(50, 52, 65));
        rightSidebarContainer.setPreferredSize(new Dimension(300, getHeight()));
        rightSidebarContainer.setBorder(new EmptyBorder(30, 20, 30, 20));

        resetRightSidebar(); // Initialize with default

        return rightSidebarContainer;
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new MainFrame().setVisible(true));
    }
}
