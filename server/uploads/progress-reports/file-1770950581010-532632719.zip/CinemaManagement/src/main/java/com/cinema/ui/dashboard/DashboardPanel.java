package com.cinema.ui.dashboard;

import com.cinema.dao.DashboardDAO;
import com.cinema.model.Movie;
import com.cinema.model.User;
import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;
import java.awt.geom.RoundRectangle2D;
import java.math.BigDecimal;
import java.text.NumberFormat;
import java.util.List;
import java.util.Locale;

public class DashboardPanel extends JPanel {

    private DashboardDAO dao;
    private User currentUser;

    private JLabel lblRevenue;
    private JLabel lblTickets;
    private JPanel movieGrid;

    public DashboardPanel(User user) {
        this.currentUser = user;
        this.dao = new DashboardDAO();
        initComponents();
        loadData();
    }

    private void initComponents() {
        setBackground(new Color(40, 42, 54)); // Dark background
        setLayout(new BoxLayout(this, BoxLayout.Y_AXIS));
        setBorder(new EmptyBorder(30, 30, 30, 30));

        // --- Header Section ---
        JPanel header = new JPanel(new BorderLayout());
        header.setOpaque(false);
        header.setAlignmentX(Component.LEFT_ALIGNMENT);
        header.setMaximumSize(new Dimension(Integer.MAX_VALUE, 60));

        JLabel title = new JLabel("Tổng Quan");
        title.setFont(new Font("Segoe UI", Font.BOLD, 32));
        title.setForeground(Color.WHITE);
        header.add(title, BorderLayout.WEST);

        JButton btnRefresh = new JButton("Cập Nhật");
        btnRefresh.setFont(new Font("Segoe UI", Font.BOLD, 14));
        btnRefresh.setForeground(Color.WHITE);
        btnRefresh.setBackground(new Color(68, 71, 90));
        btnRefresh.setFocusPainted(false);
        btnRefresh.setBorder(BorderFactory.createEmptyBorder(8, 15, 8, 15));
        btnRefresh.setCursor(new Cursor(Cursor.HAND_CURSOR));
        btnRefresh.addActionListener(e -> loadData());
        header.add(btnRefresh, BorderLayout.EAST);

        add(header);
        add(Box.createVerticalStrut(30));

        // --- Banner Stats Section ---
        JPanel bannerPanel = new JPanel(new GridLayout(1, 2, 25, 0));
        bannerPanel.setOpaque(false);
        bannerPanel.setAlignmentX(Component.LEFT_ALIGNMENT);
        bannerPanel.setMaximumSize(new Dimension(Integer.MAX_VALUE, 160));

        lblRevenue = new JLabel("Loading...");
        lblTickets = new JLabel("Loading...");

        String role = currentUser != null ? currentUser.getRole() : "GUEST";
        if ("ADMIN".equalsIgnoreCase(role)) {
            // Gradient Cards for Admin
            bannerPanel.add(new GradientCard("Doanh Thu Hôm Nay", lblRevenue,
                    new Color(189, 147, 249), new Color(139, 233, 253))); // Purple -> Cyan

            bannerPanel.add(new GradientCard("Vé Đã Bán", lblTickets,
                    new Color(255, 121, 198), new Color(255, 184, 108))); // Pink -> Orange
        } else {
            // Staff view
            bannerPanel.add(new GradientCard("Vé Đã Bán", lblTickets,
                    new Color(255, 121, 198), new Color(255, 184, 108)));

            JLabel lblStatus = new JLabel("Đang làm việc");
            bannerPanel.add(new GradientCard("Trạng Thái", lblStatus,
                    new Color(80, 250, 123), new Color(139, 233, 253))); // Green -> Cyan
        }

        add(bannerPanel);
        add(Box.createVerticalStrut(40));

        // --- Active Movies Section ---
        JLabel popTitle = new JLabel("Phim Đang Chiếu");
        popTitle.setFont(new Font("Segoe UI", Font.BOLD, 24));
        popTitle.setForeground(new Color(248, 248, 242));
        popTitle.setAlignmentX(Component.LEFT_ALIGNMENT);
        add(popTitle);
        add(Box.createVerticalStrut(20));

        movieGrid = new JPanel(new FlowLayout(FlowLayout.LEFT, 25, 25));
        movieGrid.setOpaque(false);
        movieGrid.setAlignmentX(Component.LEFT_ALIGNMENT);

        // Wrap movie grid in scroll pane purely for overflow protection (though
        // BoxLayout handles vertical)
        // But here we just add the grid directly to the vertical box
        add(movieGrid);
    }

    private void loadData() {
        SwingWorker<Void, Void> worker = new SwingWorker<>() {
            BigDecimal revenue;
            int tickets;
            List<Movie> movies;

            @Override
            protected Void doInBackground() throws Exception {
                revenue = dao.getTodayRevenue();
                tickets = dao.getTodayTicketsSold();
                movies = dao.getMoviesShowingToday();
                return null;
            }

            @Override
            protected void done() {
                // Update Stats
                try {
                    NumberFormat nf = NumberFormat.getCurrencyInstance(new Locale("vi", "VN"));
                    lblRevenue.setText(nf.format(revenue));
                } catch (Exception ex) {
                    lblRevenue.setText(revenue + " VNĐ");
                }
                lblTickets.setText(String.valueOf(tickets));

                // Update Movies
                movieGrid.removeAll();
                if (movies.isEmpty()) {
                    JLabel l = new JLabel("<html><i style='color:#6272a4'>Chưa có suất chiếu nào hôm nay</i></html>");
                    l.setFont(new Font("Segoe UI", Font.ITALIC, 16));
                    movieGrid.add(l);
                } else {
                    for (Movie m : movies) {
                        movieGrid.add(createMoviePosterCard(m));
                    }
                }
                movieGrid.revalidate();
                movieGrid.repaint();
            }
        };
        worker.execute();
    }

    // --- Custom Components ---

    // 1. Gradient Stats Card
    private static class GradientCard extends JPanel {
        private String title;
        private Component valueComp;
        private Color c1, c2;

        public GradientCard(String title, Component valueComp, Color c1, Color c2) {
            this.title = title;
            this.valueComp = valueComp;
            this.c1 = c1;
            this.c2 = c2;

            setOpaque(false);
            setLayout(new BorderLayout());
            setBorder(new EmptyBorder(25, 25, 25, 25));

            JLabel lblTitle = new JLabel(title.toUpperCase());
            lblTitle.setFont(new Font("Segoe UI", Font.BOLD, 14));
            lblTitle.setForeground(new Color(255, 255, 255, 200));
            add(lblTitle, BorderLayout.NORTH);

            valueComp.setFont(new Font("Segoe UI", Font.BOLD, 36));
            valueComp.setForeground(Color.WHITE);
            add(valueComp, BorderLayout.CENTER);
        }

        @Override
        protected void paintComponent(Graphics g) {
            Graphics2D g2 = (Graphics2D) g.create();
            g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);

            GradientPaint gp = new GradientPaint(0, 0, c1, getWidth(), getHeight(), c2);
            g2.setPaint(gp);
            g2.fillRoundRect(0, 0, getWidth(), getHeight(), 25, 25);

            // Add subtle overlay circle
            g2.setColor(new Color(255, 255, 255, 30));
            g2.fillOval(getWidth() - 80, -20, 150, 150);

            g2.dispose();
        }
    }

    // 2. Movie Poster Card
    private JPanel createMoviePosterCard(Movie m) {
        JPanel card = new JPanel() {
            @Override
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                Graphics2D g2 = (Graphics2D) g;
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                g2.setColor(new Color(68, 71, 90));
                g2.fillRoundRect(0, 0, getWidth(), getHeight(), 15, 15);
            }
        };
        card.setLayout(new BoxLayout(card, BoxLayout.Y_AXIS));
        card.setPreferredSize(new Dimension(180, 260));
        card.setOpaque(false);
        card.setBorder(new EmptyBorder(10, 10, 10, 10));

        // Poster Image
        JLabel posterLabel = new JLabel();
        posterLabel.setPreferredSize(new Dimension(160, 180));
        posterLabel.setMaximumSize(new Dimension(160, 180));
        posterLabel.setHorizontalAlignment(SwingConstants.CENTER);

        boolean imageLoaded = false;
        if (m.getPosterPath() != null && !m.getPosterPath().isEmpty()) {
            try {
                Image image = null;
                if (m.getPosterPath().startsWith("http")) {
                    image = javax.imageio.ImageIO.read(new java.net.URL(m.getPosterPath()));
                } else {
                    java.io.File imgFile = new java.io.File(m.getPosterPath());
                    if (imgFile.exists()) {
                        image = javax.imageio.ImageIO.read(imgFile);
                    }
                }

                if (image != null) {
                    Image scaled = image.getScaledInstance(160, 180, Image.SCALE_SMOOTH);
                    posterLabel.setIcon(new ImageIcon(scaled));
                    imageLoaded = true;
                }
            } catch (Exception e) {
                // Ignore, fall back to placeholder
            }
        }

        if (!imageLoaded) {
            // Placeholder
            JPanel placeholder = new JPanel(new GridBagLayout());
            placeholder.setBackground(new Color(98, 114, 164));
            placeholder.setPreferredSize(new Dimension(160, 180));
            placeholder.setMaximumSize(new Dimension(160, 180));

            JLabel lblInitial = new JLabel(m.getTitle().substring(0, 1).toUpperCase());
            lblInitial.setFont(new Font("Serif", Font.BOLD, 72));
            lblInitial.setForeground(new Color(255, 255, 255, 50));
            placeholder.add(lblInitial);

            card.add(placeholder);
        } else {
            card.add(posterLabel);
        }

        card.add(Box.createVerticalStrut(15));

        // Movie Info
        JLabel lblTitle = new JLabel(m.getTitle());
        lblTitle.setFont(new Font("Segoe UI", Font.BOLD, 16));
        lblTitle.setForeground(Color.WHITE);
        lblTitle.setAlignmentX(Component.CENTER_ALIGNMENT);
        card.add(lblTitle);

        JLabel lblGenre = new JLabel(m.getGenre());
        lblGenre.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        lblGenre.setForeground(new Color(139, 233, 253));
        lblGenre.setAlignmentX(Component.CENTER_ALIGNMENT);
        card.add(lblGenre);

        JLabel lblDuration = new JLabel(m.getDuration() + " phút");
        lblDuration.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        lblDuration.setForeground(Color.LIGHT_GRAY);
        lblDuration.setAlignmentX(Component.CENTER_ALIGNMENT);
        card.add(lblDuration);

        return card;
    }
}
