package com.cinema.util;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class DataCleanup {
    public static void main(String[] args) {
        // Cleanup Duplicate Movies
        String sqlMovies = "DELETE t1 FROM Movies t1 " +
                "INNER JOIN Movies t2 " +
                "WHERE t1.MovieId > t2.MovieId AND t1.Title = t2.Title";

        // Cleanup Duplicate Showtimes
        String sqlShowtimes = "DELETE t1 FROM Showtimes t1 " +
                "INNER JOIN Showtimes t2 " +
                "WHERE t1.ShowtimeID > t2.ShowtimeID " +
                "AND t1.MovieID = t2.MovieID " +
                "AND t1.HallID = t2.HallID " +
                "AND t1.StartTime = t2.StartTime";

        try (Connection conn = DatabaseConnection.getConnection()) {
            // Movies
            try (PreparedStatement stmt = conn.prepareStatement(sqlMovies)) {
                int deleted = stmt.executeUpdate();
                System.out.println("Removed " + deleted + " duplicate movies.");
            }

            // Showtimes
            try (PreparedStatement stmt = conn.prepareStatement(sqlShowtimes)) {
                int deleted = stmt.executeUpdate();
                System.out.println("Removed " + deleted + " duplicate showtimes.");
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}
