# Use Cases - Hệ Thống Quản Lý Rạp Chiếu Phim

## 1. Các Tác Nhân (Actors)

*   **Quản Lý (Manager/Admin):** Người có toàn quyền quản trị hệ thống, quản lý phim, lịch chiếu, nhân viên và xem báo cáo.
*   **Nhân Viên Bán Vé (Staff):** Người trực tiếp bán vé cho khách hàng tại quầy.

## 2. Danh Sách Use Case

### 2.1. Quản Lý Hệ Thống (Dành cho Admin)

#### UC01: Đăng nhập (Login)
*   **Mô tả:** Đăng nhập vào hệ thống để thực hiện các chức năng.
*   **Input:** Tên đăng nhập, Mật khẩu.
*   **Output:** Chuyển đến màn hình Dashboard chính (Admin hoặc Staff tùy quyền).

#### UC02: Quản Lý Phim (Movie Management)
*   **UC02.1: Thêm phim mới:** Nhập thông tin phim (Tên, Thể loại, Thời lượng, Đạo diễn, Mô tả, Poster, Ngày khởi chiếu).
*   **UC02.2: Sửa thông tin phim:** Cập nhật thông tin khi có sai sót hoặc thay đổi.
*   **UC02.3: Xóa phim:** Xóa phim khỏi danh sách (hoặc ẩn phim nếu đã có lịch sử chiếu).
*   **UC02.4: Tìm kiếm phim:** Tìm theo tên, thể loại.

#### UC03: Quản Lý Lịch Chiếu (Schedule Management)
*   **UC03.1: Tạo lịch chiếu:** Chọn Phim -> Chọn Phòng -> Chọn Giờ chiếu. (Hệ thống cần kiểm tra trùng giờ/phòng).
*   **UC03.2: Xem danh sách lịch chiếu:** Xem theo ngày, theo phòng.
*   **UC03.3: Hủy/Sửa lịch chiếu:** Chỉ cho phép khi chưa có vé nào được bán (hoặc quy trình hoàn vé đặc biệt).

#### UC04: Quản Lý Phòng Chiếu (Cinema Hall Management)
*   **Mô tả:** Thêm/Sửa/Xóa phòng chiếu, thiết lập sơ đồ ghế (số hàng, số cột, ghế VIP/Thường).

#### UC05: Quản Lý Nhân Viên (Staff Management)
*   **Mô tả:** Tạo tài khoản cho nhân viên bán vé, reset mật khẩu, khóa tài khoản.

#### UC06: Báo Cáo & Thống Kê (Reporting)
*   **UC06.1: Thống kê doanh thu:** Theo ngày, tháng, phim.
*   **UC06.2: Thống kê vé bán ra:** Số lượng vé, tỷ lệ lấp đầy phòng.

---

### 2.2. Bán Vé (Dành cho Staff)

#### UC07: Tra cứu Lịch Chiếu
*   **Mô tả:** Xem danh sách phim đang chiếu và sắp chiếu trong ngày để tư vấn khách.

#### UC08: Bán Vé (Booking Ticket)
*   **Bước 1 - Chọn Suất Chiếu:** Chọn phim -> Chọn giờ.
*   **Bước 2 - Chọn Ghế:** Hiển thị sơ đồ ghế (Trống, Đang chọn, Đã bán). Chọn ghế cho khách.
*   **Bước 3 - Xác nhận & Thanh toán:** Tổng tiền (tính theo loại ghế, phụ thu cuối tuần/lễ). 
*   **Bước 4 - In vé:** Lưu vào CSDL và in vé (hoặc xuất file PDF/ảnh).

#### UC09: Hủy Vé / Hoàn Vé (Refund)
*   **Mô tả:** Hủy vé vừa bán (trong khoảng thời gian cho phép) nếu khách đổi ý ngay tại quầy.

#### UC11: Đăng Ký Thành Viên (Member Registration)
*   **Mô tả:** Đăng ký tài khoản thành viên mới cho khách hàng ngay tại quầy để tích điểm.
*   **Input:** Tên, SĐT, Email (tùy chọn).

#### UC12: Quản Lý Ca (Shift Management)
*   **UC12.1: Mở ca:** Nhập số tiền mặt đầu ca (tiền lẻ thối lại).
*   **UC12.2: Chốt ca:** Nhập số tiền mặt thực tế đang có. Hệ thống tính toán chênh lệch (nếu có) so với doanh thu vé bán được.

### 2.3. Khác

#### UC10: Đăng xuất (Logout)
*   **Mô tả:** Thoát khỏi phiên làm việc an toàn.
