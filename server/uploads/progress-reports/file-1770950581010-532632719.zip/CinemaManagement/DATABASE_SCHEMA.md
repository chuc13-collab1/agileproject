# Database Schema Design

## 1. Entity Relationship Diagram (ERD)

```mermaid
erDiagram
    Users ||--o{ Bookings : creates
    Users ||--o{ Shifts : works
    Customers ||--o{ Bookings : makes
    Movies ||--o{ Showtimes : has
    CinemaHalls ||--o{ Showtimes : hosts
    CinemaHalls ||--o{ Seats : contains
    Showtimes ||--o{ Tickets : has
    Bookings ||--o{ Tickets : includes
    Seats ||--o{ Tickets : reserved_for
    Showtimes ||--o{ SeatReservations : locks
    Seats ||--o{ SeatReservations : temporarily_holds
    Users ||--o{ SeatReservations : creates
    
    Users {
        int UserID PK
        string Username
        string Role "Admin, Staff"
        boolean IsActive
    }

    Customers {
        int CustomerID PK
        string FullName
        string Phone "Unique, for loyalty"
        string Email
        int LoyaltyPoints
        datetime RegisteredAt
    }

    Movies {
        int MovieID PK
        string Title
        string Director
        string Actors
        int Duration
        date ReleaseDate
        string Genre
        string AgeRating "P, C13, C16, C18"
        string PosterPath
        string Status "Coming, Showing, Stopped"
    }

    CinemaHalls {
        int HallID PK
        string Name
        int TotalRows
        int TotalCols
    }

    Seats {
        int SeatID PK
        int HallID FK
        string RowLabel
        int SeatNumber 
        string Type "Standard, VIP"
    }

    Showtimes {
        int ShowtimeID PK
        int MovieID FK
        int HallID FK
        datetime StartTime
        datetime EndTime
        decimal BasePrice "Standard Price"
    }

    Shifts {
        int ShiftID PK
        int StaffID FK
        datetime StartTime
        datetime EndTime
        decimal StartCash
        decimal EndCash
    }

    Bookings {
        int BookingID PK
        int StaffID FK
        int CustomerID FK "Nullable"
        datetime BookingDate
        decimal TotalAmount
        int Status "Pending, Paid, Cancelled"
    }

    Tickets {
        int TicketID PK
        int BookingID FK
        int ShowtimeID FK
        int SeatID FK
        decimal Price
        string Status "Active, Refunded"
    }
    
    SeatReservations {
        int ReservationID PK
        int ShowtimeID FK
        int SeatID FK
        int StaffID FK
        datetime LockedUntil
    }
```

## 2. Table Specifications

### 2.1. Users (Quản trị & Nhân viên)
*   **UserID**: Primary Key.
*   **Role**: ADMIN hoặc STAFF.
*   **FullName**: Tên nhân viên.

### 2.2. Customers (Khách hàng & Hội viên)
Lưu trữ thông tin khách hàng thân thiết để tích điểm.
*   **CustomerID**: Primary Key.
*   **Phone**: Số điện thoại (Dùng để tra cứu nhanh).
*   **LoyaltyPoints**: Điểm tích lũy.

### 2.3. Movies (Phim)
*   **MovieID**: Primary Key.
*   **Duration**: Thời lượng (phút).
*   **ReleaseDate**: Ngày khởi chiếu.

### 2.4. CinemaHalls (Phòng chiếu)
*   **HallID**: Primary Key.
*   **Capacity**: Sức chứa (được tính từ số ghế thực tế).

### 2.5. Seats (Ghế ngồi)
*   **SeatID**: Primary Key.
*   **Detail**: Mỗi ghế thuộc về một Hall cụ thể, có Row/Col.

### 2.6. Showtimes (Lịch chiếu)
Lịch chiếu cụ thể của phim tại phòng nào, giờ nào.
*   **ShowtimeID**: Primary Key.
*   **Constraint**: Không được trùng phòng & giờ với lịch khác.

### 2.7. Bookings (Giao dịch đặt vé)
*   **BookingID**: Primary Key.
*   **CustomerID**: Nếu khách có thẻ thành viên (nếu không thì Null).
*   **TotalAmount**: Tổng tiền sau khi trừ khuyến mãi (nếu có).

### 2.8. Tickets (Chi tiết vé)
*   **TicketID**: Primary Key.
*   **Price**: Giá bán thực tế của vé này.

## 3. SQL Script (Updated)

```sql
CREATE DATABASE CinemaDB;
USE CinemaDB;

-- 1. Users
CREATE TABLE Users (
    UserID INT PRIMARY KEY AUTO_INCREMENT,
    Username VARCHAR(50) UNIQUE NOT NULL,
    PasswordHash VARCHAR(255) NOT NULL,
    FullName VARCHAR(100),
    Role ENUM('ADMIN', 'STAFF') NOT NULL,
    IsActive BOOLEAN DEFAULT TRUE,
    CreatedAt DATETIME DEFAULT CURRENT_TIMESTAMP
);

-- 1.1 Shifts (New)
CREATE TABLE Shifts (
    ShiftID INT PRIMARY KEY AUTO_INCREMENT,
    StaffID INT NOT NULL,
    StartTime DATETIME NOT NULL,
    EndTime DATETIME,
    StartCash DECIMAL(10, 2) DEFAULT 0,
    EndCash DECIMAL(10, 2),
    FOREIGN KEY (StaffID) REFERENCES Users(UserID)
);

-- 2. Customers (New)
CREATE TABLE Customers (
    CustomerID INT PRIMARY KEY AUTO_INCREMENT,
    FullName VARCHAR(100) NOT NULL,
    Phone VARCHAR(15) UNIQUE NOT NULL,
    Email VARCHAR(100),
    LoyaltyPoints INT DEFAULT 0,
    CreatedAt DATETIME DEFAULT CURRENT_TIMESTAMP
);

-- 3. Movies
CREATE TABLE Movies (
    MovieID INT PRIMARY KEY AUTO_INCREMENT,
    Title VARCHAR(200) NOT NULL,
    Description TEXT,
    Director VARCHAR(100),
    Actors TEXT, -- Cast members
    Duration INT NOT NULL, -- minutes
    ReleaseDate DATE,
    Genre VARCHAR(50),
    AgeRating VARCHAR(10), -- P, C13, C16, C18
    PosterPath VARCHAR(255),
    Status ENUM('COMING_SOON', 'SHOWING', 'STOPPED') DEFAULT 'COMING_SOON'
);

-- 4. CinemaHalls
CREATE TABLE CinemaHalls (
    HallID INT PRIMARY KEY AUTO_INCREMENT,
    Name VARCHAR(50) NOT NULL,
    TotalRows INT NOT NULL,
    TotalCols INT NOT NULL
);

-- 5. Seats
CREATE TABLE Seats (
    SeatID INT PRIMARY KEY AUTO_INCREMENT,
    HallID INT NOT NULL,
    RowLabel CHAR(2) NOT NULL, -- A, B, C...
    SeatNumber INT NOT NULL,   -- 1, 2, 3...
    SeatType ENUM('STANDARD', 'VIP') DEFAULT 'STANDARD',
    IsActive BOOLEAN DEFAULT TRUE,
    FOREIGN KEY (HallID) REFERENCES CinemaHalls(HallID),
    UNIQUE(HallID, RowLabel, SeatNumber) -- Unique seat position in a hall
);

-- 6. Showtimes
CREATE TABLE Showtimes (
    ShowtimeID INT PRIMARY KEY AUTO_INCREMENT,
    MovieID INT NOT NULL,
    HallID INT NOT NULL,
    StartTime DATETIME NOT NULL,
    EndTime DATETIME NOT NULL,
    BasePrice DECIMAL(10, 2) NOT NULL DEFAULT 50000,
    FOREIGN KEY (MovieID) REFERENCES Movies(MovieID),
    FOREIGN KEY (HallID) REFERENCES CinemaHalls(HallID)
);

-- 7. Bookings
CREATE TABLE Bookings (
    BookingID INT PRIMARY KEY AUTO_INCREMENT,
    StaffID INT NOT NULL,
    CustomerID INT, -- Nullable if guest
    BookingDate DATETIME DEFAULT CURRENT_TIMESTAMP,
    TotalAmount DECIMAL(10, 2) NOT NULL DEFAULT 0,
    Status ENUM('PENDING', 'PAID', 'CANCELLED') DEFAULT 'PENDING',
    FOREIGN KEY (StaffID) REFERENCES Users(UserID),
    FOREIGN KEY (CustomerID) REFERENCES Customers(CustomerID)
);

-- 8. Tickets
CREATE TABLE Tickets (
    TicketID INT PRIMARY KEY AUTO_INCREMENT,
    BookingID INT NOT NULL,
    ShowtimeID INT NOT NULL,
    SeatID INT NOT NULL,
    Price DECIMAL(10, 2) NOT NULL,
    Status ENUM('ACTIVE', 'REFUNDED') DEFAULT 'ACTIVE',
    FOREIGN KEY (BookingID) REFERENCES Bookings(BookingID),
    FOREIGN KEY (ShowtimeID) REFERENCES Showtimes(ShowtimeID),
    FOREIGN KEY (SeatID) REFERENCES Seats(SeatID),
    UNIQUE(ShowtimeID, SeatID) -- Constraint: A seat in a showtime can only be sold once
);

-- 9. SeatReservations (Temporary seat locks)
CREATE TABLE SeatReservations (
    ReservationID INT PRIMARY KEY AUTO_INCREMENT,
    ShowtimeID INT NOT NULL,
    SeatID INT NOT NULL,
    StaffID INT NOT NULL, -- Staff who is reserving the seat
    LockedUntil DATETIME NOT NULL, -- Reservation expires after this time
    FOREIGN KEY (ShowtimeID) REFERENCES Showtimes(ShowtimeID),
    FOREIGN KEY (SeatID) REFERENCES Seats(SeatID),
    FOREIGN KEY (StaffID) REFERENCES Users(UserID),
    UNIQUE(ShowtimeID, SeatID) -- A seat can only have one active reservation
);
```
