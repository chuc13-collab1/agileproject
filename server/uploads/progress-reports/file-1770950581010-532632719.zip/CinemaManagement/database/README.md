# Database Setup Guide

## Hướng dẫn cài đặt Database MySQL

### Bước 1: Cài đặt MySQL
Nếu chưa cài MySQL, tải và cài đặt từ: https://dev.mysql.com/downloads/mysql/

### Bước 2: Chạy MySQL Server
Khởi động MySQL server (hoặc dùng XAMPP/WAMP nếu có).

### Bước 3: Tạo Database và Tables

**Cách 1: Sử dụng MySQL Command Line**
```bash
# Đăng nhập MySQL
mysql -u root -p

# Chạy schema.sql
source e:/CinemaManagement/database/schema.sql

# Chạy sample_data.sql (tùy chọn - để có dữ liệu test)
source e:/CinemaManagement/database/sample_data.sql
```

**Cách 2: Sử dụng MySQL Workbench**
1. Mở MySQL Workbench
2. Kết nối đến MySQL Server
3. File → Open SQL Script → Chọn `schema.sql`
4. Click ⚡ Execute
5. Lặp lại với `sample_data.sql` (nếu muốn dữ liệu mẫu)

**Cách 3: Sử dụng phpMyAdmin (nếu dùng XAMPP)**
1. Truy cập http://localhost/phpmyadmin
2. Tab "Import"
3. Choose File → `schema.sql` → Go
4. Lặp lại với `sample_data.sql`

### Bước 4: Cấu hình kết nối trong ứng dụng
Chỉnh sửa file `src/main/resources/database.properties`:
```properties
db.url=jdbc:mysql://localhost:3306/CinemaDB
db.username=root
db.password=YOUR_MYSQL_PASSWORD
```

### Bước 5: Kiểm tra
Chạy các query sau để kiểm tra:
```sql
USE CinemaDB;
SHOW TABLES;
SELECT * FROM Users;
SELECT * FROM Movies;
```

## Thông tin tài khoản mẫu (sau khi import sample_data.sql)

| Username | Password  | Role  |
|----------|-----------|-------|
| admin    | admin123  | ADMIN |
| staff01  | admin123  | STAFF |
| staff02  | admin123  | STAFF |

> ⚠️ **Lưu ý**: Password đã được hash bằng BCrypt. Trong code Java, bạn cần dùng BCrypt để verify password.

## Cấu trúc Database

### Tổng quan:
- **10 Tables**: Users, Shifts, Customers, Movies, CinemaHalls, Seats, Showtimes, Bookings, Tickets, SeatReservations
- **96 Seats** (Hall 01: 96, Hall 02: 60)
- **4 Movies** mẫu
- **7 Showtimes** trong ngày 2026-01-25

### Dữ liệu mẫu:
- 3 Users (1 admin, 2 staff)
- 3 Customers với điểm tích lũy
- 4 Movies với các thể loại khác nhau
- 3 Cinema Halls
- 156 Seats (tự động generate)
- 7 Showtimes
- 3 Bookings với 5 tickets đã bán
