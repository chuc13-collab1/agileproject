-- Sample Data for Cinema Management System
-- Run this after schema.sql

USE CinemaDB;

-- Insert Admin and Staff users
INSERT INTO Users (Username, PasswordHash, FullName, Role, IsActive) VALUES
('admin', '$2a$10$wSsq.e/2g.j.H.W/i.b.u.k.j.h.g.f.d.s.a.1.2.3.4.5.6.7.8.9', 'Nguyễn Văn A', 'ADMIN', TRUE), -- password: admin123
('staff01', '$2a$10$wSsq.e/2g.j.H.W/i.b.u.k.j.h.g.f.d.s.a.1.2.3.4.5.6.7.8.9', 'Trần Thị B', 'STAFF', TRUE), -- password: admin123
('staff02', '$2a$10$wSsq.e/2g.j.H.W/i.b.u.k.j.h.g.f.d.s.a.1.2.3.4.5.6.7.8.9', 'Lê Văn C', 'STAFF', TRUE);

-- Insert Sample Customers
INSERT INTO Customers (FullName, Phone, Email, LoyaltyPoints) VALUES
('Phạm Minh D', '0901234567', 'minhtd@gmail.com', 150),
('Hoàng Thị E', '0912345678', 'hoange@gmail.com', 300),
('Vũ Quốc F', '0923456789', NULL, 50);

-- Insert Movies
INSERT INTO Movies (Title, Description, Director, Actors, Duration, ReleaseDate, Genre, AgeRating, PosterPath, Status) VALUES
('Avengers: Endgame', 'Cuộc chiến cuối cùng của các siêu anh hùng', 'Anthony Russo', 'Robert Downey Jr., Chris Evans, Scarlett Johansson', 181, '2024-04-26', 'Action, Sci-Fi', 'C13', 'media/posters/avengers_endgame.jpg', 'SHOWING'),
('Titanic', 'Chuyện tình trên con tàu huyền thoại', 'James Cameron', 'Leonardo DiCaprio, Kate Winslet', 194, '2024-02-14', 'Romance, Drama', 'C16', 'media/posters/titanic.jpg', 'SHOWING'),
('Inception', 'Giấc mơ trong giấc mơ', 'Christopher Nolan', 'Leonardo DiCaprio, Ellen Page', 148, '2024-07-16', 'Sci-Fi, Thriller', 'C13', 'media/posters/inception.jpg', 'COMING_SOON'),
('The Lion King', 'Vua sư tử trở lại', 'Jon Favreau', 'Donald Glover, Beyoncé', 118, '2024-05-01', 'Animation, Family', 'P', 'media/posters/lion_king.jpg', 'SHOWING');

-- Insert Cinema Halls
INSERT INTO CinemaHalls (Name, TotalRows, TotalCols) VALUES
('Hall 01 - Standard', 8, 12),
('Hall 02 - VIP', 6, 10),
('Hall 03 - IMAX', 10, 15);

-- Insert Seats for Hall 01 (8 rows x 12 cols)
INSERT INTO Seats (HallID, RowLabel, SeatNumber, SeatType, IsActive) 
SELECT 1, 
    CHAR(64 + r) AS RowLabel, 
    c AS SeatNumber,
    CASE WHEN r >= 6 THEN 'VIP' ELSE 'STANDARD' END AS SeatType,
    TRUE
FROM 
    (SELECT 1 AS r UNION SELECT 2 UNION SELECT 3 UNION SELECT 4 UNION SELECT 5 UNION SELECT 6 UNION SELECT 7 UNION SELECT 8) AS row_nums,
    (SELECT 1 AS c UNION SELECT 2 UNION SELECT 3 UNION SELECT 4 UNION SELECT 5 UNION SELECT 6 
     UNION SELECT 7 UNION SELECT 8 UNION SELECT 9 UNION SELECT 10 UNION SELECT 11 UNION SELECT 12) AS col_nums;

-- Insert Seats for Hall 02 (6 rows x 10 cols, all VIP)
INSERT INTO Seats (HallID, RowLabel, SeatNumber, SeatType, IsActive)
SELECT 2,
    CHAR(64 + r) AS RowLabel,
    c AS SeatNumber,
    'VIP' AS SeatType,
    TRUE
FROM 
    (SELECT 1 AS r UNION SELECT 2 UNION SELECT 3 UNION SELECT 4 UNION SELECT 5 UNION SELECT 6) AS row_nums,
    (SELECT 1 AS c UNION SELECT 2 UNION SELECT 3 UNION SELECT 4 UNION SELECT 5 
     UNION SELECT 6 UNION SELECT 7 UNION SELECT 8 UNION SELECT 9 UNION SELECT 10) AS col_nums;

-- Insert Showtimes (Multiple showtimes across different halls)
INSERT INTO Showtimes (MovieID, HallID, StartTime, EndTime, BasePrice) VALUES
-- Avengers
(1, 1, '2026-01-25 10:00:00', '2026-01-25 13:01:00', 80000),
(1, 2, '2026-01-25 14:00:00', '2026-01-25 17:01:00', 120000),
(1, 1, '2026-01-25 18:00:00', '2026-01-25 21:01:00', 80000),

-- Titanic
(2, 3, '2026-01-25 09:00:00', '2026-01-25 12:14:00', 90000),
(2, 1, '2026-01-25 15:00:00', '2026-01-25 18:14:00', 80000),

-- Lion King
(4, 2, '2026-01-25 10:30:00', '2026-01-25 12:28:00', 100000),
(4, 3, '2026-01-25 16:00:00', '2026-01-25 17:58:00', 90000);

-- Insert some sample bookings
INSERT INTO Bookings (StaffID, CustomerID, BookingDate, TotalAmount, Status) VALUES
(2, 1, '2026-01-24 14:30:00', 240000, 'PAID'),
(2, 2, '2026-01-24 15:00:00', 160000, 'PAID'),
(3, NULL, '2026-01-24 16:00:00', 80000, 'PAID'); -- Guest customer

-- Insert tickets for those bookings
-- Booking 1: 2 VIP tickets for Avengers at Hall 2 (2pm show)
INSERT INTO Tickets (BookingID, ShowtimeID, SeatID, Price, Status) VALUES
(1, 2, (SELECT SeatID FROM Seats WHERE HallID=2 AND RowLabel='C' AND SeatNumber=5), 120000, 'ACTIVE'),
(1, 2, (SELECT SeatID FROM Seats WHERE HallID=2 AND RowLabel='C' AND SeatNumber=6), 120000, 'ACTIVE');

-- Booking 2: 2 standard tickets for Avengers at Hall 1 (10am show)
INSERT INTO Tickets (BookingID, ShowtimeID, SeatID, Price, Status) VALUES
(2, 1, (SELECT SeatID FROM Seats WHERE HallID=1 AND RowLabel='D' AND SeatNumber=7), 80000, 'ACTIVE'),
(2, 1, (SELECT SeatID FROM Seats WHERE HallID=1 AND RowLabel='D' AND SeatNumber=8), 80000, 'ACTIVE');

-- Booking 3: 1 ticket for Lion King
INSERT INTO Tickets (BookingID, ShowtimeID, SeatID, Price, Status) VALUES
(3, 6, (SELECT SeatID FROM Seats WHERE HallID=2 AND RowLabel='B' AND SeatNumber=3), 100000, 'ACTIVE');

-- Update customer loyalty points based on bookings
UPDATE Customers SET LoyaltyPoints = LoyaltyPoints + 24 WHERE CustomerID = 1; -- 10% of 240k
UPDATE Customers SET LoyaltyPoints = LoyaltyPoints + 16 WHERE CustomerID = 2; -- 10% of 160k

SELECT 'Sample data inserted successfully!' AS Status;
