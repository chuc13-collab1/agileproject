-- Cinema Management System Database Schema
-- Updated: 2026-01-24
-- This script creates all tables required for the system

CREATE DATABASE IF NOT EXISTS CinemaDB;
USE CinemaDB;

-- 1. Users (Admin & Staff)
CREATE TABLE Users (
    UserID INT PRIMARY KEY AUTO_INCREMENT,
    Username VARCHAR(50) UNIQUE NOT NULL,
    PasswordHash VARCHAR(255) NOT NULL,
    FullName VARCHAR(100),
    Role ENUM('ADMIN', 'STAFF') NOT NULL,
    IsActive BOOLEAN DEFAULT TRUE,
    CreatedAt DATETIME DEFAULT CURRENT_TIMESTAMP
);

-- 2. Shifts (Work shifts for staff)
CREATE TABLE Shifts (
    ShiftID INT PRIMARY KEY AUTO_INCREMENT,
    StaffID INT NOT NULL,
    StartTime DATETIME NOT NULL,
    EndTime DATETIME,
    StartCash DECIMAL(10, 2) DEFAULT 0,
    EndCash DECIMAL(10, 2),
    FOREIGN KEY (StaffID) REFERENCES Users(UserID)
);

-- 3. Customers (Members with loyalty points)
CREATE TABLE Customers (
    CustomerID INT PRIMARY KEY AUTO_INCREMENT,
    FullName VARCHAR(100) NOT NULL,
    Phone VARCHAR(15) UNIQUE NOT NULL,
    Email VARCHAR(100),
    LoyaltyPoints INT DEFAULT 0,
    CreatedAt DATETIME DEFAULT CURRENT_TIMESTAMP
);

-- 4. Movies
CREATE TABLE Movies (
    MovieID INT PRIMARY KEY AUTO_INCREMENT,
    Title VARCHAR(200) NOT NULL,
    Description TEXT,
    Director VARCHAR(100),
    Actors TEXT,
    Duration INT NOT NULL, -- minutes
    ReleaseDate DATE,
    Genre VARCHAR(50),
    AgeRating VARCHAR(10), -- P, C13, C16, C18
    PosterPath VARCHAR(255),
    Status ENUM('COMING_SOON', 'SHOWING', 'STOPPED') DEFAULT 'COMING_SOON'
);

-- 5. CinemaHalls
CREATE TABLE CinemaHalls (
    HallID INT PRIMARY KEY AUTO_INCREMENT,
    Name VARCHAR(50) NOT NULL,
    TotalRows INT NOT NULL,
    TotalCols INT NOT NULL
);

-- 6. Seats
CREATE TABLE Seats (
    SeatID INT PRIMARY KEY AUTO_INCREMENT,
    HallID INT NOT NULL,
    RowLabel CHAR(2) NOT NULL,
    SeatNumber INT NOT NULL,
    SeatType ENUM('STANDARD', 'VIP') DEFAULT 'STANDARD',
    IsActive BOOLEAN DEFAULT TRUE,
    FOREIGN KEY (HallID) REFERENCES CinemaHalls(HallID),
    UNIQUE(HallID, RowLabel, SeatNumber)
);

-- 7. Showtimes
CREATE TABLE Showtimes (
    ShowtimeID INT PRIMARY KEY AUTO_INCREMENT,
    MovieID INT NOT NULL,
    HallID INT NOT NULL,
    StartTime DATETIME NOT NULL,
    EndTime DATETIME NOT NULL,
    BasePrice DECIMAL(10, 2) NOT NULL DEFAULT 50000,
    FOREIGN KEY (MovieID) REFERENCES Movies(MovieID),
    FOREIGN KEY (HallID) REFERENCES CinemaHalls(HallID)
);

-- 8. Bookings
CREATE TABLE Bookings (
    BookingID INT PRIMARY KEY AUTO_INCREMENT,
    StaffID INT NOT NULL,
    CustomerID INT,
    BookingDate DATETIME DEFAULT CURRENT_TIMESTAMP,
    TotalAmount DECIMAL(10, 2) NOT NULL DEFAULT 0,
    Status ENUM('PENDING', 'PAID', 'CANCELLED') DEFAULT 'PENDING',
    FOREIGN KEY (StaffID) REFERENCES Users(UserID),
    FOREIGN KEY (CustomerID) REFERENCES Customers(CustomerID)
);

-- 9. Tickets
CREATE TABLE Tickets (
    TicketID INT PRIMARY KEY AUTO_INCREMENT,
    BookingID INT NOT NULL,
    ShowtimeID INT NOT NULL,
    SeatID INT NOT NULL,
    Price DECIMAL(10, 2) NOT NULL,
    Status ENUM('ACTIVE', 'REFUNDED') DEFAULT 'ACTIVE',
    FOREIGN KEY (BookingID) REFERENCES Bookings(BookingID),
    FOREIGN KEY (ShowtimeID) REFERENCES Showtimes(ShowtimeID),
    FOREIGN KEY (SeatID) REFERENCES Seats(SeatID),
    UNIQUE(ShowtimeID, SeatID)
);

-- 10. SeatReservations (Temporary seat locks)
CREATE TABLE SeatReservations (
    ReservationID INT PRIMARY KEY AUTO_INCREMENT,
    ShowtimeID INT NOT NULL,
    SeatID INT NOT NULL,
    StaffID INT NOT NULL,
    LockedUntil DATETIME NOT NULL,
    FOREIGN KEY (ShowtimeID) REFERENCES Showtimes(ShowtimeID),
    FOREIGN KEY (SeatID) REFERENCES Seats(SeatID),
    FOREIGN KEY (StaffID) REFERENCES Users(UserID),
    UNIQUE(ShowtimeID, SeatID)
);
