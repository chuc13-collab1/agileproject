# Poster Image Placeholder

This is a placeholder for movie posters. In production:
- Admin will upload real movie posters through the UI
- Posters should be in JPG or PNG format
- Recommended size: 300x450 pixels (2:3 ratio)

File: avengers_endgame.jpg
